const DateMonths = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const DateWeekDays = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

const APICallStatus = {
  SUCCESS: 'SUCCESS',
  ERROR: 'ERROR'
}

export {
  DateMonths,
  DateWeekDays,
  APICallStatus,
}