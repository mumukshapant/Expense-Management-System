import React from "react";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { userProfileSelector } from "../redux/selectors/app";
// import { isUserLoggedInSelector } from "../redux/selectors/auth";
const ProtectedRoute = ({ children }) => {
  // const isUserLoggedIn = useSelector(isUserLoggedInSelector);
  const userProfile = useSelector(userProfileSelector);
  if(!userProfile?.userName) {
    return <Navigate to="/" />;
  }

  // if (!isUserLoggedIn) {
  //   return <Navigate to="/" />;
  // }
  return children;
};

export default ProtectedRoute;
