package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.Currency;
import com.dbms.Expense.Management.Service.ICurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CurrencyController {
    @Autowired
    ICurrencyService service;

    @PostMapping("/addCurrency")
    public int saveCurrency(@RequestBody Currency currency) {
        return service.insertCurrency(currency);
    }


    @DeleteMapping("/deleteCurrency/{abbreviation}")
    public int deleteCurrency(@PathVariable(value = "abbreviation") String abbreviation) {
        return service.deleteCurrency(abbreviation);
    }


    @GetMapping("/findCurrency/{abbreviation}")
    public Currency findCurrency(@PathVariable(value = "abbreviation") String abbreviation) {
        return service.findCurrency(abbreviation);
    }


    @GetMapping("/findAllCurrency")
    public List<Currency> getCurrency() {
        return service.findAllCurrency();
    }


    @PutMapping("/updateCurrency")
    public int updateCurrency(@RequestBody Currency currency) {
        return service.updateCurrency(currency);
    }


}