package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Currency;
import com.dbms.Expense.Management.Repository.CurrencyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CurrencyService implements ICurrencyService {


    @Autowired
    private CurrencyRepository currencyRepository;

    @Override
    public int insertCurrency(Currency currency) {
        if (currencyExists(currency.getAbbreviation())) {
            System.out.println("Currency already exists with abbreviation: " + currency.getAbbreviation());
            return 0;
        }

        return currencyRepository.add(currency);
    }


    @Override
    public int deleteCurrency(String abbreviation) {
        int status = 0;
        if (!currencyExists(abbreviation)) {
            System.out.println("Currency Doesn't Exists: " + abbreviation);
            return status;
        }
        status = currencyRepository.delete(abbreviation);
        if (status == 1) {
            System.out.println("currency deleted successfully : " + abbreviation);
        } else {
            System.out.println("Unable to delete currency: " + abbreviation);
        }
        return status;
    }

    @Override
    public Currency findCurrency(String abbreviation) {

        if (!currencyExists(abbreviation)) {
            System.out.println("Can't Find - Currency Doesn't Exists: ");
            return null;
        }


        return currencyRepository.find(abbreviation);
    }

    @Override
    public List<Currency> findAllCurrency() {
        return currencyRepository.findAllCurrency();
    }

    @Override
    public boolean currencyExists(String abbreviation) {

        return currencyRepository.currencyExists(abbreviation);
    }


    @Override
    public int updateCurrency(Currency currency) {

        if (!currencyRepository.currencyExists(currency.getAbbreviation())) {
            System.out.println("Currency Doesn't Exist:" + currency.getAbbreviation());
            return 0;
        }
        int status = currencyRepository.update(currency);

        return status;
    }


}

