package com.dbms.Expense.Management.Model;

import java.util.Date;

public class Deposit {
    private Long deposit_id;
    private float amount;
    private String description;
    private String currency;

    public Long getDeposit_id() {
        return deposit_id;
    }

    public float getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getCurrency() {
        return currency;
    }

    public Date getDeposit_date() {
        return deposit_date;
    }

    public String getUser_name() {
        return user_name;
    }

    private Date deposit_date;

    public Deposit() {
    }

    public void setDeposit_id(Long deposit_id) {
        this.deposit_id = deposit_id;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setDeposit_date(Date deposit_date) {
        this.deposit_date = deposit_date;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public Deposit(Long deposit_id, float amount, String description, String currency, Date deposit_date, String user_name) {
        this.deposit_id = deposit_id;
        this.amount = amount;
        this.description = description;
        this.currency = currency;
        this.deposit_date = deposit_date;
        this.user_name = user_name;
    }

    private String user_name;
};
