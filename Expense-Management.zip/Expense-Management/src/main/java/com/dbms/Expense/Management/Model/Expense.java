package com.dbms.Expense.Management.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

public class Expense {
    private Long expense_id;
    private float amount;
    private String description;
    private String currency;

    public Long getExpense_id() {
        return expense_id;
    }

    public Expense() {
    }

    public Expense(Long expense_id, float amount, String description, String currency, Date creation_date, String category, int shared_count) {
        this.expense_id = expense_id;
        this.amount = amount;
        this.description = description;
        this.currency = currency;
        this.creation_date = creation_date;
        this.category = category;
        this.shared_count = shared_count;
    }

    public void setExpense_id(Long expense_id) {
        this.expense_id = expense_id;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setShared_count(int shared_count) {
        this.shared_count = shared_count;
    }

    public float getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getCurrency() {
        return currency;
    }

    public Date getCreation_date() {
        return creation_date;
    }

    public String getCategory() {
        return category;
    }

    public int getShared_count() {
        return shared_count;
    }

    private Date creation_date;
    private String category;
    private int shared_count;
};
