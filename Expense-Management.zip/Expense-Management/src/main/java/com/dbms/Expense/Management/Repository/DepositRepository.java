package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.Deposit;
import com.dbms.Expense.Management.Model.Expense;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class DepositRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    class DepositRowMapper implements RowMapper<Deposit> {

        @Override
        public Deposit mapRow(ResultSet rs, int rowNum) throws SQLException {
            Deposit deposit = new Deposit();
            deposit.setDeposit_id(rs.getLong("deposit_id"));
            deposit.setAmount(rs.getFloat("amount"));
            deposit.setDescription(rs.getString("description"));
            deposit.setCurrency(rs.getString("currency"));
            deposit.setDeposit_date(rs.getDate("deposit_date"));
            deposit.setUser_name(rs.getString("user_name"));

            return deposit;
        }

    }


    public int add(Deposit deposit) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("insert_deposit");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("description", deposit.getDescription())
                .addValue("amount", deposit.getAmount())
                .addValue("currency", deposit.getCurrency())
                .addValue("deposit_date", deposit.getDeposit_date())
                .addValue("user_name", deposit.getUser_name());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public int delete(Long deposit_id) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_deposit");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("specific_deposit_id", deposit_id);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public List<Deposit> findAll() {
        try {
            return jdbcTemplate.query("select * from deposit", new DepositRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public List<Deposit> findByUsername(String userName) {
        try {


            return jdbcTemplate.query("select * from deposit where user_name = ?", new Object[]{userName},
                    new DepositRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


};

