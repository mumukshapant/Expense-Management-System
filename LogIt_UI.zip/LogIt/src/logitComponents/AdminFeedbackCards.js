import axios from 'axios';
import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';
import { refreshData } from '../redux/thunks/refresh.thunk';



const AdminFeedbackCards = (props) => {

  const handleDelete = async (id) => {
    try {
      console.log(id, 'called');
      const response = await axios.delete(`http://localhost:8080/deleteFeedback/${id}`)
      if(response?.data==1){
        console.log("feedback deleted")
      }
    props.fetchFeedbacks();
    refreshData();
    } catch (error) {
      
    }
  }
  return (
    <Row className="mx-0">
        <h2>Here is the list of feedbacks from users:</h2>
      {props.feedbackList.map((feedback) => (
        <Col key={feedback} sm={12} md={6} lg={4} className="p-3">
          <Card >
            <Card.Body style={{backgroundColor:"#BBD6B8"}}>
              <Card.Title>
                <strong>Username:</strong> {feedback.user_name}
              </Card.Title>
              <Card.Text>
                {feedback.user_email_address}
              </Card.Text>
             
              <Card.Text><strong>Description :</strong><br/>
             {feedback.description}
              </Card.Text>

              <Card.Text><strong>Creation Date :</strong><br/>
             {feedback.creation_date}
              </Card.Text>
             
        <button onClick={() => handleDelete(feedback.feedback_id)}>Delete</button>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default AdminFeedbackCards;
