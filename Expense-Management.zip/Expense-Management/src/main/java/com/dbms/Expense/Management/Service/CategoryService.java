package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Category;
import com.dbms.Expense.Management.Repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService implements ICategoryService {
    @Autowired
    CategoryRepository categoryRepository;

    @Override
    public int addCategory(String category_name) {
        if (categoryRepository.categoryExists(category_name)) {
            System.out.println("Category Already Exist: " + category_name);
            return -1;
        }
        return categoryRepository.add(category_name);
    }

    @Override
    public int delete(String category) {

        int status = 0;

        if (!categoryRepository.categoryExists(category)) {
            System.out.println("Category Doesn't Exist: " + category);
            return status;
        }
        status = categoryRepository.delete(category);
        if (status == 1) {
            System.out.println("category deleted successfully : " + category);
        } else {
            System.out.println("Unable to delete category: " + category);
        }
        return status;
    }

    @Override
    public List<String> findAllCategories() {
        return categoryRepository.findAllCategories();
    }

    @Override
    public int addCategoryList(List<String> categoryName) {
        for (String i : categoryName
        ) {
            categoryRepository.add(i);
        }
        return 1;
    }


    @Override
    public int updateCategory(String oldCategoryName, String newCategoryName) {
        if (!categoryRepository.categoryExists(oldCategoryName)) {
            System.out.println("Category Doesn't Exist: " + oldCategoryName);
            return 0;
        }
        return categoryRepository.update(oldCategoryName, newCategoryName);
    }
}
