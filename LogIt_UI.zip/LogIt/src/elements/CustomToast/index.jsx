import React, { useState } from 'react';
import Toast from 'react-bootstrap/Toast';

function CustomToast(props) {

  return (
    <Toast show={props?.visible} onClose={props?.onClose} delay={3000} autohide style={{position: 'absolute', right: 20, top: 60, borderLeftColor: props?.type === 'success' ? 'green' : props?.type === 'error' ? 'red' : '', borderLeftWidth: 10}}>
      <Toast.Body>{props?.text}</Toast.Body>
    </Toast>
  );
}

export default CustomToast;