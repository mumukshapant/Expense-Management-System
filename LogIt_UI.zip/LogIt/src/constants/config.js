export const Config = {
  apis: {
    sendPushNotification: `/v1/firebase-notification/sendNotificationsDashboard`,
    kyc: {
      fetchPendingUsers: '/v1/getUserInfoByPendingKyc',
    },
    auth: {
      phoneSignin: `/v1/auth/signin`,
      tokenCheck: `/v1/auth/isTokenValid`,
      verifyOtp: `/v1/auth/verifyOtp`,
      tokenCheck: `/v1/auth/isTokenValid`,
    },
    transactions: {
      fetchAllCardVerifications: `/v1/transactions/getAllCardVerificationTransactions`,
      issueCardVerificationRefund: `/v1/transactions/issueAddNewCardRefund`,
    },
    notifications: {
      sendEarlyAccessMail: `/v1/bills/sendEarlyAccessMail`,
      sendMail: `/v1/user/sendDownloadDynamicBodyMail`,
    },
    bills: {
      captureAndSettleBill: `/v1/bills/captureAndCloseBill`,
      fetchUserBill: `/v1/bills/getOverDueBillsByUserId`,
    }
  }
}