import React, { useState } from 'react';
import { Button } from 'react-bootstrap';
import DepositModal from './DepositModal';
import { useSelector } from 'react-redux';
import { currenciesSelector } from '../redux/selectors/app';

const DepositComponent = (props) => {
  const [showModal, setShowModal] = useState(false);
  const currencies = useSelector(currenciesSelector);

  const handleAddDeposit = (deposit) => {
    // Add the deposit to your application's data
    console.log('Deposit added:', deposit);
  };

  return (
    <>
      <Button onClick={() => setShowModal(true)}>Add Deposit</Button>
      <DepositModal
        show={showModal}
        onHide={() => setShowModal(false)}
        onDeposit={handleAddDeposit}
        currencies = {currencies}
      />
    </>
  );
};

export default DepositComponent;
