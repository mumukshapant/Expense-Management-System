import { useEffect, useState } from 'react';
import { Modal, Button, Form, Alert } from 'react-bootstrap';
import { useSelector } from 'react-redux';
import { currenciesSelector, usernamesSelector } from '../redux/selectors/app';
import axios from 'axios';
import { refreshData } from '../redux/thunks/refresh.thunk';

export default function CreateUserModal(props) {
  // const [usernames, setUsernames] = useState(['user1', 'user2', 'user3']);
  const [username, setUsername] = useState('');
  const [error, setError] = useState(false);

  const currencies = useSelector(currenciesSelector);
  const usernames = useSelector(usernamesSelector);

  useEffect(() => {
    if (!props.show) {
      // Reset the userData state to its initial value
      setUserData({
        admin: false,
        userName: '',
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        emailId: '',
        gender: 'MALE',
        contactNumber: '',
        domesticCurrency: 'USD',
      });
    }
  }, [props.show]);

  const [userData, setUserData] = useState({
    admin: false,
    userName: '',
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    emailId: '',
    gender: 'MALE',
    contactNumber: '',
    domesticCurrency: 'USD',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUserData({ ...userData, [name]: value });
  };
  const handleInputusername = (event) => {
    const { name, value } = event.target;
    setUserData({ ...userData, [name]: value });

    if (usernames.includes(value)) {
      console.log('Username already exists. Please select different username!');
      setError(true)
      // You can show an error message to the user here
    }else{
      setError(false)
    }
  };
  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (usernames.includes(userData.userName)) {
      alert('This username already exists. Please enter a different username.');
    } else {
      props.onAddUser(userData);
      props.onHide();
    }
  };

  const handleUserCreate = async () => {
    if(error){
      alert('Invalid Feilds! Please retry!');
    }else{
    try {
      console.log(userData);
      const response = await axios.post('http://localhost:8080/adduser', userData);
      console.log(response, 'xyz')
      if(response?.data === 1) {
        alert("User registeration successful!");
        refreshData();
        props?.onHide();
      } else {
        // Alert'Something went wrong')
      }
    } catch (error) {
      console.log(error)
    }}
  }

  return (
    <Modal {...props} centered>
      <Modal.Header closeButton>
        <Modal.Title>Create New User</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleFormSubmit}>
          <Form.Group controlId="userName">
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              name="userName"
              value={userData.userName}
              onChange={handleInputusername}
              style={{ borderColor: error ? 'red' : 'initial' }}
            />{error && <p style={{ color: 'red' }}>Username already exists</p>}
          </Form.Group>

          <Form.Group controlId="firstName">
            <Form.Label>First Name</Form.Label>
            <Form.Control
              type="text"
              name="firstName"
              value={userData.firstName}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Form.Group controlId="lastName">
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              type="text"
              name="lastName"
              value={userData.lastName}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Form.Group controlId="dateOfBirth">
            <Form.Label>Date of Birth</Form.Label>
            <Form.Control
              type="date"
              name="dateOfBirth"
              value={userData.dateOfBirth}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Form.Group controlId="emailId">
            <Form.Label>Email Address</Form.Label>
            <Form.Control
              type="email"
              name="emailId"
              value={userData.emailId}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Form.Group controlId="gender">
            <Form.Label>Gender</Form.Label>
            <Form.Control
              as="select"
              name="gender"
              value={userData.gender}
              onChange={handleInputChange}
            >
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </Form.Control>
          </Form.Group>

          <Form.Group controlId="contactNumber">
            <Form.Label>Contact Number</Form.Label>
            <Form.Control
              type="tel"
              name="contactNumber"
              value={userData.contactNumber}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Form.Group controlId="domesticCurrency">
            <Form.Label>Domestic Currency</Form.Label>
            <Form.Control
              as="select"
              name="domesticCurrency"
              value={userData.domesticCurrency}
              onChange={handleInputChange}
            >
                <option value="">Select a currency</option>
    {currencies.map(currency => (
      <option key={currency.abbreviation} value={currency.abbreviation}>
        {currency.abbreviation}
      </option>
    ))}
            </Form.Control>
          </Form.Group>

          <Button variant="primary" onClick={handleUserCreate} disabled={error}>
            Create User 
          </Button></Form></Modal.Body></Modal>);}
