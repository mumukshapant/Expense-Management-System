package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class CategoryRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;


    class CategoryRowMapper implements RowMapper<Category> {

        @Override
        public Category mapRow(ResultSet rs, int rowNum) throws SQLException {
            Category category = new Category();

            category.setCategory(rs.getString("category_name"));

            return category;
        }

    }


    public int add(String category_name) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("create_category");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("name", category_name);

        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }


    public int delete(String category) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_category");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("name", category);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public List<String> findAllCategories() {
        try {
            List<Category> result = jdbcTemplate.query("select * from  categories", new CategoryRowMapper());
            List<String> stringList = new ArrayList<>();

            for (int i = 0; i < result.size(); i++) {
                stringList.add(result.get(i).getCategory());
            }
            return stringList;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public boolean categoryExists(String category) {
        String sql = "SELECT COUNT(*) FROM categories WHERE category_name = ?";
        try {
            Integer count = jdbcTemplate.queryForObject(
                    sql, new Object[]{category}, Integer.class);
            return count != null && count > 0;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return false;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return false;
        }
    }


    public int update(String oldCategoryName, String newCategoryName) {
        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("update_category");

            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue("oldName", oldCategoryName)
                    .addValue("newName", newCategoryName);

            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }
}
