package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.*;
import com.dbms.Expense.Management.Service.FeedbackService;
import com.dbms.Expense.Management.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class FeedbackRepository {

    @Autowired
    FeedbackService feedbackService;

    @Autowired
    JdbcTemplate jdbcTemplate;

    class FeedbackRowMapper implements RowMapper<Feedback> {
        @Override
        public Feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
            Feedback feedback = new Feedback();
            feedback.setFeedback_id(rs.getLong("feedback_id"));
            feedback.setQuery(rs.getBoolean("is_query"));
            feedback.setDescription(rs.getString("description"));
            feedback.setCreation_date(rs.getDate("creation_date"));
            feedback.setUser_name(rs.getString("user_name"));
            feedback.setUser_email_address(rs.getString("user_email_address"));
            return feedback;


        }
    }

    public List<Feedback> getAllFeedback() {
        try {
            List<Feedback> result =
                    jdbcTemplate.query("call find_feedbacks()", new FeedbackRepository.FeedbackRowMapper());

            return result;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public List<Feedback> getAllQuery() {
        try {
            List<Feedback> result =
                    jdbcTemplate.query("call find_queries()", new FeedbackRepository.FeedbackRowMapper());

            return result;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public int insertFeedback(Feedback feedback) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("insert_feedback");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("is_query", feedback.isQuery())
                .addValue("description", feedback.getDescription())
                .addValue("user_name", feedback.getUser_name())
                .addValue("user_email_address", feedback.getUser_email_address());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;


        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public int delete(int id) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_feedback");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("id", id);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;

        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }


};


