import axios from 'axios';
import React, { useState } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import { refreshData } from '../redux/thunks/refresh.thunk';

const CurrencyTable = ({ currencies, onUpdate, onDelete, onAdd }) => {
  const [showModal, setShowModal] = useState(false);
  const [editedCurrency, setEditedCurrency] = useState(null);
  const [newCurrency, setNewCurrency] = useState({});

  const handleShowModal = (currency) => {
    setEditedCurrency(currency);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditedCurrency(null);
  };

  const handleUpdate = async () => {
    // const { name, abbreviation, rate } = event.target.elements;
    console.log(editedCurrency,newCurrency )
    const updatedCurrency = {
      id: editedCurrency.id,
      ...editedCurrency,
      ...newCurrency,
    //   currency_name: newCurrency.currency_name,
    //   abbreviation: editedCurrency?.abbreviation,
    //   rate: Number(newCurrency.rate.value),
    };
    // onUpdate(updatedCurrency);
    const response = await axios.put(`http://localhost:8080/updateCurrency`, updatedCurrency);
    if(response?.data == 1) {
        handleCloseModal();
        refreshData()
    } else {
        // show alert
    }
  };

  const handleDelete = async (id) => {
    // onDelete(currency);
    console.log("Deleted Currency :" +id)
    const response = await axios.delete(`http://localhost:8080/deleteCurrency/${id}`);
    if(response?.data == 1) {
        handleCloseModal();
        refreshData()
    } else {
        // show alert
    }
  };

  const handleAdd = async () => {
    try {
        const response = await axios.post(`http://localhost:8080/addCurrency`,newCurrency);
        console.log(response, 'xyzxyz')
        if(response?.data === 1) {
            handleCloseModal();
            refreshData()
        } else {
          // show alert
        }
      } catch (error) {
        console.log('An error occurred while adding the currency.', error);
      }
    };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setNewCurrency({ ...newCurrency, [name]: value });
  };

  return (
    <>
    <Button variant="primary" onClick={() => setShowModal(true)}>
        Add Currency
      </Button><br></br>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Currency Name</th>
            <th>Abbreviation</th>
            <th>Rate</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currencies.map((currency) => (
            <tr key={currency.id}>
              <td>{currency.currency_name}</td>
              <td>{currency.abbreviation}</td>
              <td>{currency.rate}</td>
              <td>
                <Button variant="primary" onClick={() => handleShowModal(currency)}>
                  Update
                </Button>{' '}
                <Button variant="danger" onClick={() => handleDelete(currency?.abbreviation)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>


      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>{editedCurrency ? 'Update Currency' : 'Add Currency'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="name">
              <Form.Label>Currency Name</Form.Label>
              <Form.Control
                type="text"
                defaultValue={editedCurrency?.currency_name}
                name="currency_name"
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            <Form.Group controlId="abbreviation">
              <Form.Label>Abbreviation</Form.Label>
              <Form.Control
                type="text"
                defaultValue={editedCurrency?.abbreviation}
                name="abbreviation"
                onChange={handleInputChange}
                required
                disabled={editedCurrency ? true : false}
              />
            </Form.Group>
            <Form.Group controlId="rate">
              <Form.Label>Rate</Form.Label>
              <Form.Control
                type="number"
                step="0.01"
                defaultValue={editedCurrency?.rate}
                name="rate"
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            <Button variant="primary" onClick={editedCurrency ? handleUpdate : handleAdd}> Save Changes</Button>
</Form></Modal.Body></Modal></>);
}
export default CurrencyTable;