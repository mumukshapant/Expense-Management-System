package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Expense;
import com.dbms.Expense.Management.Model.ExpensePerUserModel;
import com.dbms.Expense.Management.Model.InsertExpenseModel;
import com.dbms.Expense.Management.Model.User;
import com.dbms.Expense.Management.Repository.ExpenseRepository;
import com.dbms.Expense.Management.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService implements IExpenseService {
    @Autowired
    private ExpenseRepository expenseRepository;

    @Override
    public int deleteExpense(Long expense_id) {
        return expenseRepository.delete(expense_id);
    }

    @Override
    public Expense findExpense(Long expense_id) {
        return expenseRepository.find(expense_id);
    }


    @Override
    public List<Expense> findAllExpense() {
        return expenseRepository.findAll();
    }

    @Override
    public int insertExpense(InsertExpenseModel expense) {
        return expenseRepository.insertExpense(expense);
    }

    @Override
    public List<ExpensePerUserModel> findExpenseByUsername(String username) {
        return expenseRepository.findAllExpensePerUser(username);
    }

}



