package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.User;

import java.util.List;

public interface IUserService {

    public int insertUser(User user);

    public User getUserInfo(String username);

    public int deleteUser(String username);

    public List<User> findAll();

    public boolean isValidUser(String username);

    boolean updateUser(User user);

    List<String> getUsername();

    float getBalance(String username);
}
