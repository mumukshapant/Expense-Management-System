import React,{useEffect, useState} from 'react'
import './cards.css'
import { Card, Col, Row, Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import { useSelector } from 'react-redux';
import { expensesSelector, userProfileSelector } from '../redux/selectors/app';
import axios from 'axios';
import { fetchExpenses, refreshData } from '../redux/thunks/refresh.thunk';

export default function ExpenseCards(props) {    
  const userProfile = useSelector(userProfileSelector);
  // const [expenses, setExpenses ] = useState([]);
  const expenses = useSelector(expensesSelector);

  useEffect(() => {
    fetchExpenses();
  }, [])
 
  const handleDelete = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/deleteExpense/${id}`)
      console.log(response.data)
      if(response?.data==1){
        alert('Expense deleted successfully!');
        // setExpenses(expenses.filter((expense) => expense.id !== id));
        refreshData();
      }
      // props.fetchHistory();
      // fetchExpenses();
    } catch (error) {
      
    }
  }
return(
<Container className='appContainer '>
    <Row xs={1} md={3} className='pt-5'>
        {
            expenses.map( expense=> 
              <Col className='my-2'>
           <Card style={{backgroundColor: expense.shared_count>1 ? '#FFABAB' : '#D14D72'}}>
      <Card.Body className="text-dark">
        <Card.Title>Expense Details</Card.Title>
       {expense.shared_count==1 &&<Card.Text>Amount: {expense.currency} {expense.amount} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Total Amount: {expense.currency} {expense.amount} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Per Person Amount: {expense.currency} {expense.actual_total_amount} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Split parts count: {expense.shared_count}</Card.Text>}
        <Card.Text>Description: {expense.description}</Card.Text>
        <Card.Text>Creation Date: {expense.creation_date}</Card.Text> 
        <Card.Text>Expense Category: {expense.category}</Card.Text> 
        <button onClick={() => handleDelete(expense?.expense_id)}>Delete</button>
      </Card.Body>
    </Card>
         </Col>
              )
            
        }
        
    </Row>

</Container>)
}
