import { createSelector } from "reselect";

export const appSliceSelector = (state) => state.app || {};

export const userProfileSelector = createSelector(appSliceSelector, appState => appState && appState.userProfile || {});

export const currenciesSelector = createSelector(appSliceSelector, appState => appState && appState.currencies || []);

export const categoriesSelector = createSelector(appSliceSelector, appState => appState && appState.categories || []);

export const usernamesSelector = createSelector(appSliceSelector, appState => appState && appState.usernames || []);

export const depositsSelector = createSelector(appSliceSelector, appState => appState && appState.deposits || []);

export const expensesSelector = createSelector(appSliceSelector, appState => appState && appState.expenses || []);

export const historySelector = createSelector(appSliceSelector, appState => appState && appState.history || []);

export const feedbacksSelector = createSelector(appSliceSelector, appState => appState && appState.feedbacks || []);

export const balanceSelector = createSelector(appSliceSelector, appState => appState && appState.balance || []);