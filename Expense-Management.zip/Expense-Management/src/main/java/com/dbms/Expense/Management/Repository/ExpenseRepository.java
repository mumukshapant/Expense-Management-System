package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.*;
import com.dbms.Expense.Management.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class ExpenseRepository {
    @Autowired
    UserService userService;

    @Autowired
    JdbcTemplate jdbcTemplate;

    class ExpenseRowMapper implements RowMapper<Expense> {
        @Override
        public Expense mapRow(ResultSet rs, int rowNum) throws SQLException {
            Expense expense = new Expense();
            expense.setExpense_id(rs.getLong("expense_id"));
            expense.setCurrency(rs.getString("currency"));
            expense.setAmount(rs.getFloat("amount"));
            expense.setCreation_date(rs.getDate("creation_date"));
            expense.setDescription(rs.getString("description"));
            expense.setCategory(rs.getString("category"));
            expense.setShared_count(rs.getInt("shared_count"));
            return expense;
        }
    }

    class ExpensePerUserRowMapper implements RowMapper<ExpensePerUserModel> {
        @Override
        public ExpensePerUserModel mapRow(ResultSet rs, int rowNum) throws SQLException {
            ExpensePerUserModel expense = new ExpensePerUserModel();
            expense.setExpense_id(rs.getLong("expense_id"));
            expense.setCurrency(rs.getString("currency"));
            expense.setAmount(rs.getFloat("amount"));
            expense.setCreation_date(rs.getDate("creation_date"));
            expense.setDescription(rs.getString("description"));
            expense.setCategory(rs.getString("category"));
            expense.setShared_count(rs.getInt("shared_count"));
            expense.setActual_total_amount(rs.getFloat("actual_total"));
            return expense;
        }


    }

    public int delete(Long expense_id) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("delete_expense");

        SqlParameterSource inParams = new MapSqlParameterSource().addValue("specific_expense_id", expense_id);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");
            return rowsAffected;

        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }


    public Expense find(Long expense_id) {
        try {
            return jdbcTemplate.queryForObject("SELECT * FROM expense WHERE expense_id = ?", new Object[]{expense_id},
                    (rs, rowNum) -> new Expense(
                            rs.getLong("expense_id"),
                            rs.getFloat("amount"),
                            rs.getString("description"),
                            rs.getString("currency"),
                            rs.getDate("creation_date"),
                            rs.getString("category"),
                            rs.getInt("shared_count")
                    ));
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public List<Expense> findAll() {
        try {
            return jdbcTemplate.query("select * from expense", new ExpenseRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public int insertExpense(InsertExpenseModel expenseModel) {
        int status = 0;
        for (String username : expenseModel.getUsernames()
        ) {
            if (!userService.isValidUser(username)) {
                System.out.println("Invalid username :" + username);
                return 0;
            }

        }
        try {
            String usernames = String.join(",", expenseModel.getUsernames());

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("insert_expense");

            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue("description", expenseModel.getDescription())
                    .addValue("amount", expenseModel.getAmount())
                    .addValue("currency", expenseModel.getCurrency())
                    .addValue("creation_date", expenseModel.getCreation_date())
                    .addValue("category", expenseModel.getCategory())
                    .addValue("p_usernames", usernames);
            Map<String, Object> out = jdbcCall.execute(inParams);

            status = (Integer) out.get("rowsAffected");


        } catch (Exception e) {
            System.out.println("Exception occured while adding expense :" + e);
        }
        return status;
    }

    public List<ExpensePerUserModel> findAllExpensePerUser(String username) {
        try {
            return jdbcTemplate.query("call find_expense_by_username (?)", new Object[]{username},
                    new ExpensePerUserRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

};


