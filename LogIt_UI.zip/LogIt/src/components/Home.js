import React, { useEffect, useState } from "react";
import { Button, Card, Col, Container, Modal, Row } from "react-bootstrap";
import { useNavigate } from "react-router";
import axios from 'axios';
import { useSelector } from "react-redux";
import { categoriesSelector, currenciesSelector, historySelector, userProfileSelector } from "../redux/selectors/app";
import DepositComponent from "../logitComponents/DepositComponent";
import ExpenseModal from "../logitComponents/ExpenseModal";
import logit from '../logitComponents/LogitConstants';
import UserCard from "../logitComponents/UserCard";
import DepositCards from "../logitComponents/DepositCards";
import ExpenseCards from "../logitComponents/ExpenseCards";
import CreateUserModal from "../logitComponents/CreateUserModal";
import HistoryCards from "../logitComponents/HistoryCards";
import MyTable from "../logitComponents/MyTable";
import CurrencyTable from "../logitComponents/CurrencyTable";
import FeedbackCard from "../logitComponents/FeedbackCard";
import { fetchHistory,fetchBa, fetchDeposits, fetchBalance } from "../redux/thunks/refresh.thunk";


 const Home = () => {
  const [showUpdateModal, setUpdateModal] = useState(false);
  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const navigate = useNavigate();
  const userProfile = useSelector(userProfileSelector);

  const updateProfile = async () => {
    try {
      // const response = await 
    } catch (error) {

    }
  }

  const tempList = [];

  const [showCreatUserModal, setShowCreatUserModal] = useState(false);

  const handleCreateUser = (userData) => {
    // Do something with the user data
    console.log(userData);
  };

  const handleCloseCreatUserModal = () => {
    setShowCreatUserModal(false);
  };

  const handleOpenCreatUserModal = () => {
    setShowCreatUserModal(true);
  };

  const history = useSelector(historySelector);
  const [deposits, setDeposits] = useState(logit.deposits);
  const [expenses, setExpenses] = useState(logit.expenses);
  const categories = useSelector(categoriesSelector);
  const currencies =  useSelector(currenciesSelector);


  const user = useSelector(userProfileSelector)

  useEffect(() => {
    fetchHistory();
    fetchBalance();
  }, [])

  return (
    <>
      <Container style={{ paddingTop: "4%" }}>
        <Row>
          <Col xs={12} sm={6} md={4} lg={3}>
            <div className="mb-4">
              <UserCard user={user} currencies={currencies} />
            </div>
            <div className="mb-4">
              <FeedbackCard/>
            </div>
          </Col>
          <Col xs={12} sm={6} md={8} lg={9}>
          <div className="d-flex justify-content-between mb-4 lp-4">
  <DepositComponent />
  <ExpenseModal />
</div>

<div className="mb-4">
  <h2>Deposits :</h2>
  <DepositCards fetchHistory={fetchHistory}/>
</div>
<div className="mb-4">
  <h2>Expenses :</h2>
  <ExpenseCards fetchHistory={fetchHistory} expenses={expenses} />
</div>
<div className="mb-4">
  <h2>History :</h2>
  <HistoryCards history={history} />
</div>

</Col></Row></Container></>);}
export default Home;