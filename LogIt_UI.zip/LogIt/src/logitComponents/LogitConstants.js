// const deposits = [
//     {
//       "deposit_id": 6,
//       "amount": 22.3343,
//       "description": "My earning from January",
//       "currency": "USD",
//       "deposit_date": "2023-04-29",
//       "user_name": "PantIshaan"
//     },
//     {
//       "deposit_id": 7,
//       "amount": 9098,
//       "description": "Last Year balance",
//       "currency": "USD",
//       "deposit_date": "2022-11-30",
//       "user_name": "saini.ishaan"
//     },
//     {
//       "deposit_id": 8,
//       "amount": 4536,
//       "description": "personal savings",
//       "currency": "USD",
//       "deposit_date": "2023-01-31",
//       "user_name": "saini.ishaan"
//     },
//     {
//       "deposit_id": 9,
//       "amount": 33,
//       "description": "personal deposit",
//       "currency": "USD",
//       "deposit_date": "2022-09-30",
//       "user_name": "saini.ishaan"
//     },
//     {
//       "deposit_id": 12,
//       "amount": 78.8,
//       "description": "description for my deposit",
//       "currency": "INR",
//       "deposit_date": "2023-03-05",
//       "user_name": "ashish@123"
//     },
//     {
//       "deposit_id": 13,
//       "amount": 89,
//       "description": "mother gave pocket money",
//       "currency": "EUR",
//       "deposit_date": "2023-02-05",
//       "user_name": "anandaar"
//     },
//     {
//       "deposit_id": 17,
//       "amount": 10,
//       "description": "trying",
//       "currency": "USD",
//       "deposit_date": "2023-04-08",
//       "user_name": "dhr"
//     }
//   ]
// const expenses = 
//   [
//     {
//       "expense_id": 1,
//       "amount": 100,
//       "description": "Pizza",
//       "currency": "USD",
//       "creation_date": "2023-04-07",
//       "category": "Food",
//       "shared_count": 1,
//       "actual_total_amount": 100
//     },
//     {
//       "expense_id": 12,
//       "amount": 120,
//       "description": "test row count",
//       "currency": "INR",
//       "creation_date": "1997-11-05",
//       "category": "Deposit",
//       "shared_count": 1,
//       "actual_total_amount": 120
//     },
//     {
//       "expense_id": 15,
//       "amount": 10,
//       "description": "hey split update ",
//       "currency": "USD",
//       "creation_date": "2023-04-13",
//       "category": "Food",
//       "shared_count": 2,
//       "actual_total_amount": 5
//     }
//   ]


//   const allCategories=[
//     "Charity/Donations",
//     "Clothing",
//     "Deposit",
//     "Education",
//     "Electronics",
//     "Entertainment",
//     "Food",
//     "Health care",
//     "Housing",
//     "Personal care",
//     "Savings and investment",
//     "Shopping",
//     "string",
//     "Transport"
//   ]



//   const currency =
//     [
//       {
//         "currency_name": "Australian Dollar",
//         "abbreviation": "AUD",
//         "rate": 0.72
//       },
//       {
//         "currency_name": "Brazilian Real",
//         "abbreviation": "BRL",
//         "rate": 0.8
//       },
//       {
//         "currency_name": "Canadian Dollar",
//         "abbreviation": "CAD",
//         "rate": 0.8
//       },
//       {
//         "currency_name": "Swiss Franc",
//         "abbreviation": "CHF",
//         "rate": 1.05
//       },
//       {
//         "currency_name": "Chinese Yuan",
//         "abbreviation": "CNY",
//         "rate": 1.05
//       },
//       {
//         "currency_name": "Euro",
//         "abbreviation": "EUR",
//         "rate": 1.17
//       },
//       {
//         "currency_name": "British Pound Sterling",
//         "abbreviation": "GBP",
//         "rate": 1.4
//       },
//       {
//         "currency_name": "Hong Kong Dollar",
//         "abbreviation": "HKD",
//         "rate": 0.13
//       },
//       {
//         "currency_name": "Indian Rupee",
//         "abbreviation": "INR",
//         "rate": 0.01
//       },
//       {
//         "currency_name": "Japanese Yen",
//         "abbreviation": "JPY",
//         "rate": 0.01
//       },
//       {
//         "currency_name": "South Korean Won",
//         "abbreviation": "KRW",
//         "rate": 0
//       },
//       {
//         "currency_name": "Russian Ruble",
//         "abbreviation": "RUB",
//         "rate": 0.14
//       },
//       {
//         "currency_name": "Swedish Krona",
//         "abbreviation": "SEK",
//         "rate": 0.12
//       },
//       {
//         "currency_name": "Singapore Dollar",
//         "abbreviation": "SGD",
//         "rate": 0.73
//       },
//       {
//         "currency_name": "Turkish Lira",
//         "abbreviation": "TRY",
//         "rate": 0.12
//       },
//       {
//         "currency_name": "United States Dollar",
//         "abbreviation": "USD",
//         "rate": 1
//       },
//       {
//         "currency_name": "South African Rand",
//         "abbreviation": "ZAR",
//         "rate": 0.07
//       }
//     ];


//   const history =[
//       {
//         "logit_history_id": 2,
//         "amount": 10312,
//         "description": "finallyyyyyy",
//         "currency": "usd",
//         "creation_date": "2013-11-02",
//         "deletion_date": "2023-04-07",
//         "category": "Food",
//         "shared_count": 2,
//         "history_type": "Expense",
//         "amount_per_user": 5156
//       },
//       {
//         "logit_history_id": 3,
//         "amount": 10,
//         "description": "heyyy",
//         "currency": "usd",
//         "creation_date": "2013-11-02",
//         "deletion_date": "2023-04-07",
//         "category": "Food",
//         "shared_count": 2,
//         "history_type": "Expense",
//         "amount_per_user": 5
//       },
//       {
//         "logit_history_id": 5,
//         "amount": 1200,
//         "description": "test row count",
//         "currency": "INR",
//         "creation_date": "1997-11-05",
//         "deletion_date": "2023-04-07",
       
//         "shared_count": 1,
//         "history_type": "Deposit",
//         "amount_per_user": 1200
//       }
//     ]
  
//   export default {deposits,expenses,allCategories,currency,history};