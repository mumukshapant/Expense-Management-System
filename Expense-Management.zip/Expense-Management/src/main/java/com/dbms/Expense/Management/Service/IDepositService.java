package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Deposit;

import java.util.List;

public interface IDepositService {

    public int insertDeposit(Deposit deposit);

    public int deleteDeposit(Long deposit_id);

    public List<Deposit> findAllDeposit();

    List<Deposit> findDepositByUsername(String userName);
}
