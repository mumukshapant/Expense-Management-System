package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Service.ICategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CategoryController {
    @Autowired
    ICategoryService service;

    @PostMapping("/addCategory/{category_name}")
    public int addCategory(@PathVariable(value = "category_name") String category_name) {
        return service.addCategory(category_name);
    }

    @DeleteMapping("/deleteCategory/{category_name}")
    public int deleteCategory(@PathVariable(value = "category_name") String category_name) {
        return service.delete(category_name);
    }


    @GetMapping("/findAllCategories")
    public List<String> getCategories() {
        return service.findAllCategories();
    }


    @PostMapping("/addCategoryList")
    public int addCategoryList(@RequestBody List<String> category_name) {
        return service.addCategoryList(category_name);
    }

    @PutMapping("/updatecategory")
    public int update(String OldCategoryName, String NewCategoryName) {
        return service.updateCategory(OldCategoryName, NewCategoryName);
    }


}
