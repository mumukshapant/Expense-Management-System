package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.Gender;
import com.dbms.Expense.Management.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class UserRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;


    class UserRowMapper implements RowMapper<User> {
        @Override
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = new User();
            user.setContactNumber(rs.getLong("contact_number"));
            user.setFirstName(rs.getString("first_name"));
            user.setLastName(rs.getString("last_name"));
            user.setEmailId(rs.getString("email_address"));
            user.setUserName(rs.getString("user_name"));
            user.setDateOfBirth(rs.getDate("date_of_birth"));
            user.setGender(Gender.valueOf(rs.getString("gender")));
            user.setDomesticCurrency(rs.getString("domestic_currency"));
            user.setAdmin(rs.getBoolean("is_admin"));
            return user;
        }
    }

    public List<User> findAll() {
        try {
            return jdbcTemplate.query("select * from user", new UserRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public User findByUserName(String username) {
        try {

            return jdbcTemplate.queryForObject("select * from user where user_name=?", new Object[]{
                            username
                    },
                    (rs, rowNum) -> new User(
                            rs.getString("user_name"),
                            rs.getString("first_name"),
                            rs.getString("last_name"),
                            rs.getDate("date_of_birth"),
                            rs.getString("email_address"),
                            Gender.valueOf(rs.getString("gender")),
                            rs.getLong("contact_number"),
                            rs.getString("domestic_currency"),
                            rs.getBoolean("is_admin")
                    ));
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    public int deleteByUserName(String username) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_user");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("username", username);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;

        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public int insert(User user) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("create_user");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("user_name", user.getUserName())
                .addValue("first_name", user.getFirstName())
                .addValue("last_name", user.getLastName())
                .addValue("email_address", user.getEmailId())
                .addValue("gender", user.getGender())
                .addValue("contact_number", user.getContactNumber())
                .addValue("date_of_birth", user.getDateOfBirth())
                .addValue("domestic_currency", user.getDomesticCurrency())
                .addValue("is_admin", user.isAdmin());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;

        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public int update(User user) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("update_user");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("p_user_name", user.getUserName())
                .addValue("first_name", user.getFirstName())
                .addValue("last_name", user.getLastName())
                .addValue("email_address", user.getEmailId())
                .addValue("gender", user.getGender())
                .addValue("contact_number", user.getContactNumber())
                .addValue("date_of_birth", user.getDateOfBirth())
                .addValue("domestic_currency", user.getDomesticCurrency());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public boolean userExists(String username) {
        String sql = "SELECT COUNT(*) FROM user WHERE user_name = ?";
        try {
            Integer count = jdbcTemplate.queryForObject(
                    sql, new Object[]{username}, Integer.class);
            return count != null && count > 0;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return false;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return false;
        }
    }

    public float getUserBalance(String username) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("calculate_user_expense");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("p_username", username);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            BigDecimal balance = (BigDecimal) out.get("balance");
            float response = balance.floatValue();

            return response;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }
};