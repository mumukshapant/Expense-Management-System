package com.dbms.Expense.Management.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

public class LogitHistory {

    private Long logit_history_id;
    private Float amount;
    private String description;
    private String currency;
    private Date creation_date;
    private Date deletion_date;
    private String category;
    private int shared_count;
    private String history_type;
    private float amount_per_user;

    public LogitHistory(Long logit_history_id, Float amount, String description, String currency, Date creation_date, Date deletion_date, String category, int shared_count, String history_type, float amount_per_user) {
        this.logit_history_id = logit_history_id;
        this.amount = amount;
        this.description = description;
        this.currency = currency;
        this.creation_date = creation_date;
        this.deletion_date = deletion_date;
        this.category = category;
        this.shared_count = shared_count;
        this.history_type = history_type;
        this.amount_per_user = amount_per_user;
    }

    public LogitHistory() {
    }

    public Long getLogit_history_id() {
        return logit_history_id;
    }

    public void setLogit_history_id(Long logit_history_id) {
        this.logit_history_id = logit_history_id;
    }

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    public Date getDeletion_date() {
        return deletion_date;
    }

    public void setDeletion_date(Date deletion_date) {
        this.deletion_date = deletion_date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getShared_count() {
        return shared_count;
    }

    public void setShared_count(int shared_count) {
        this.shared_count = shared_count;
    }

    public String getHistory_type() {
        return history_type;
    }

    public void setHistory_type(String history_type) {
        this.history_type = history_type;
    }

    public float getAmount_per_user() {
        return amount_per_user;
    }

    public void setAmount_per_user(float amount_per_user) {
        this.amount_per_user = amount_per_user;
    }
};
