package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.LogitHistory;

import java.util.List;

public interface IHistoryService {
    
    public List<LogitHistory> findAllHistory();

    public List<LogitHistory> findHistoryByUsername(String username);

}
