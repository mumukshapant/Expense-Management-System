package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Expense;
import com.dbms.Expense.Management.Model.ExpensePerUserModel;
import com.dbms.Expense.Management.Model.InsertExpenseModel;
import com.dbms.Expense.Management.Model.User;

import java.util.List;

public interface IExpenseService {


    public int deleteExpense(Long expense_id);

    public Expense findExpense(Long expenseId);

    public List<Expense> findAllExpense();

    public int insertExpense(InsertExpenseModel expense);

    List<ExpensePerUserModel> findExpenseByUsername(String username);
}
