package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Feedback;

import java.util.List;

public interface IFeedbackService {

    public List<Feedback> getAllFeedback();
//   public List<String> getAllQuery();

    public int addFeedback(Feedback feedback);

    public List<Feedback> getAllQuery();

    int delete(int feedbackId);
}
