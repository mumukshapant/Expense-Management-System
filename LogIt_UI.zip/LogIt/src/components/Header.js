import userEvent from "@testing-library/user-event";
import { Button, Image } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { useNavigate } from "react-router-dom";
import { useUserAuth } from "../context/UserAuthContext";
import RiveNameLogo from "../assets/images/riveNameLogo.png";
import { useSelector } from "react-redux";
import { logout } from "../redux/thunks/auth.thunk";
import { userProfileSelector } from "../redux/selectors/app";

function Header(props) {

  const userProfile = useSelector(userProfileSelector);

  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      navigate("/");
    } catch (error) {
      console.log(error.message);
    }
  };
  return (
    <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand href="/home">
          <h1><b>LogIt</b></h1>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">

        </Navbar.Collapse>
        <Navbar.Collapse className="justify-content-end">
          <h2>Hi! {userProfile.firstName} {userProfile.lastName }</h2>
          <Button
            style={{ marginLeft: "20px" }}
            variant="primary"
            onClick={handleLogout}
          >
            Log out
          </Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;
