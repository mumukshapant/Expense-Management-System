package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Feedback;
import com.dbms.Expense.Management.Model.User;
import com.dbms.Expense.Management.Repository.FeedbackRepository;
import com.dbms.Expense.Management.Repository.LogitHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackService implements IFeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;


    @Override
    public int addFeedback(Feedback feedback) {
        return feedbackRepository.insertFeedback(feedback);
    }

    @Override
    public List<Feedback> getAllFeedback() {
        return feedbackRepository.getAllFeedback();
    }


    @Override
    public List<Feedback> getAllQuery() {
        return feedbackRepository.getAllQuery();
    }

    @Override
    public int delete(int feedbackId) {
        return feedbackRepository.delete(feedbackId);
    }


}
