import { AppType } from '../../constants';
import { ACTION_TYPES } from '../constants/actionTypes';

const initialState = {
  userProfile: {},
  currencies: [],
  categories: [],
  usernames:[],
  deposits: [],
  history: [],
  expenses: [],
  feedbacks: [],
  balance:[]
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ACTION_TYPES.APP.USER_PROFILE:
      return {
        ...state,
        userProfile: action.data
      }
    case ACTION_TYPES.APP.CURRENCIES:
      return {
        ...state,
        currencies: action.data
      }
    case ACTION_TYPES.APP.CATEGORIES:
      return {
        ...state,
        categories: action.data
      }
    case ACTION_TYPES.APP.USERNAMES:
      return {
        ...state,
        usernames: action.data
      }
    case ACTION_TYPES.APP.DEPOSITS:
      return {
        ...state,
        deposits: action.data
      }
    case ACTION_TYPES.APP.EXPENSES:
      return {
        ...state,
        expenses: action.data
      }
    case ACTION_TYPES.APP.HISTORY:
      return {
        ...state,
        history: action.data
      }
    case ACTION_TYPES.APP.FEEDBACKS:
      return {
        ...state,
        feedbacks: action.data
      }
    case ACTION_TYPES.APP.BALANCE:
        return {
          ...state,
          balance: action.data
        }
    default:
      
      return state;
  }
};

export default reducer;
