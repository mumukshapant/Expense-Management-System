package com.dbms.Expense.Management.Model;

import java.util.Date;


public class User {
    private String userName;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String emailId;
    private Gender gender;
    private Long contactNumber;
    private String domesticCurrency = "USD";
    private boolean isAdmin = false;

    public User() {
    }

    public User(String userName, String firstName, String lastName, Date dateOfBirth, String emailId, Gender gender, Long contactNumber, String domesticCurrency, boolean isAdmin) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.emailId = emailId;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.domesticCurrency = domesticCurrency;
        this.isAdmin = isAdmin;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Long getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(Long contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getDomesticCurrency() {
        return domesticCurrency;
    }

    public void setDomesticCurrency(String domesticCurrency) {
        this.domesticCurrency = domesticCurrency;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }
};