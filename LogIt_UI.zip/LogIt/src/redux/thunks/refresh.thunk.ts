import axios from "axios";
import store from "../store";
import { setBalance, setCategories, setCurrencies, setDeposits, setExpenses, setFeedbacks, setHistory, setUserProfile, setUsernames } from "../actions/app";
import { userProfileSelector } from "../selectors/app";

export const fetchUser = async () => {
    const dispatch = store.dispatch;
    const profile = userProfileSelector(store.getState());
    const response = await axios.get(`http://localhost:8080/getuser/${profile?.userName}`);
    const userProfile = response?.data;
    dispatch(setUserProfile(userProfile));
}

export const fetchDeposits = async () => {
    const dispatch = store.dispatch;
    const profile = userProfileSelector(store.getState());
    const response = await axios.get(`http://localhost:8080/findDepositByUsername/${profile?.userName}`)
    // setDeposits(response?.data);
    dispatch(setDeposits(response?.data));
}

export const fetchExpenses = async () => {
    const dispatch = store.dispatch;
    const userProfile = userProfileSelector(store.getState());
    const response = await axios.get(`http://localhost:8080/findExpenseByUsername/${userProfile?.userName}`)
    dispatch(setExpenses(response?.data));
}

export const fetchHistory = async () => {
    const dispatch = store.dispatch;
    const userProfile = userProfileSelector(store.getState());
    const response = await axios.get(`http://localhost:8080/findAllHistory/${userProfile?.userName}`);

    dispatch(setHistory(response?.data));
}

export const fetchFeedbacks = async () => {
try {
    const dispatch = store.dispatch;
    const response = await axios.get(`http://localhost:8080/getAllFeedback`)
    dispatch(setFeedbacks(response?.data));
} catch (error) {
    
}
}

const fetchUsernames = async () => {
    try {
        const dispatch = store.dispatch;
      const response = await axios.get('http://localhost:8080/getUsername');
      dispatch(setUsernames(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

  const fetchCurrencies = async () => {
    try {
        const dispatch = store.dispatch;
      const response = await axios.get('http://localhost:8080/findAllCurrency');
      dispatch(setCurrencies(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

  const fetchCategories = async () => {
    try {
        const dispatch = store.dispatch;
      const response = await axios.get('http://localhost:8080/findAllCategories');
      dispatch(setCategories(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

 export const fetchBalance = async () => {
    const dispatch = store.dispatch;
    const userProfile = userProfileSelector(store.getState());
    const response = await axios.get(`http://localhost:8080/getuserbalance/${userProfile?.userName}`);
    dispatch(setBalance(response?.data));
    console.log(response)
  }

export const refreshData = () => {
    fetchUser();
    fetchDeposits();
    fetchExpenses();
    fetchHistory();
    fetchFeedbacks();
    fetchUsernames();
    fetchCategories();
    fetchCurrencies();
    fetchBalance();
}