import { applyMiddleware, createStore, compose, Store } from 'redux';
import reduxThunk from 'redux-thunk';
import { createLogger } from 'redux-logger';

import reducers from '../reducers';

let middlewares = [reduxThunk];
// if (__DEV__) {
  const loggerMiddleware = createLogger();
  middlewares = [...middlewares, loggerMiddleware];
// }
let enhancer = compose(applyMiddleware(...middlewares));


const store = createStore(reducers, enhancer);

export default store;
