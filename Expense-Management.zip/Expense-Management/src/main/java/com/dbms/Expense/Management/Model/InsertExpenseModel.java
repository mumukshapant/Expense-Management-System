package com.dbms.Expense.Management.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;


public class InsertExpenseModel {
    private float amount;
    private String description;
    private String currency;
    private Date creation_date;


    private String category;
    private List<String> usernames;

    public InsertExpenseModel(float amount, String description, String currency, Date creation_date, String category, List<String> usernames) {
        this.amount = amount;
        this.description = description;
        this.currency = currency;
        this.creation_date = creation_date;
        this.category = category;
        this.usernames = usernames;
    }

    public InsertExpenseModel() {
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(List<String> usernames) {
        this.usernames = usernames;
    }
}
