package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.LogitHistory;
import com.dbms.Expense.Management.Repository.LogitHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class HistoryService implements IHistoryService {

    @Autowired
    private LogitHistoryRepository historyRepository;

    @Override
    public List<LogitHistory> findAllHistory() {
        return historyRepository.findAll();
    }

    @Override
    public List<LogitHistory> findHistoryByUsername(String username) {
        return historyRepository.findAllHistoryPerUser(username);
    }


}
