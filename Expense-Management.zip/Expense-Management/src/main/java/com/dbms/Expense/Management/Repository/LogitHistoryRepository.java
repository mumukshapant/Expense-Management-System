package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.ExpensePerUserModel;
import com.dbms.Expense.Management.Model.LogitHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class LogitHistoryRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;


    class HistoryRowMapper implements RowMapper<LogitHistory> {

        @Override
        public LogitHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
            LogitHistory history = new LogitHistory();

            history.setLogit_history_id(rs.getLong("logit_history_id"));
            history.setAmount(rs.getFloat("amount"));
            history.setDescription(rs.getString("description"));
            history.setCurrency(rs.getString("currency"));
            history.setCreation_date(rs.getDate("creation_date"));
            history.setDeletion_date(rs.getDate("deletion_date"));
            history.setHistory_type(rs.getString("history_type"));
            history.setShared_count(rs.getInt("shared_count"));
            history.setCategory(rs.getString("category"));
            history.setAmount_per_user(rs.getFloat("actual_total"));
            return history;
        }

    }


    public List<LogitHistory> findAll() {
        try {
            return jdbcTemplate.query("select * from logit_history", new HistoryRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public List<LogitHistory> findAllHistoryPerUser(String username) {
        try {
            return jdbcTemplate.query("call find_history_by_username (?)", new Object[]{username},
                    new HistoryRowMapper());
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


};
