package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Deposit;
import com.dbms.Expense.Management.Model.Expense;
import com.dbms.Expense.Management.Repository.DepositRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DepositService implements IDepositService {

    @Autowired
    private DepositRepository depositRepository;
    @Autowired
    UserService userService;


    @Override
    public int insertDeposit(Deposit deposit) {
        if (!userService.isValidUser(deposit.getUser_name())) {
            System.out.println("username is not valid");
        }
        int status = depositRepository.add(deposit);
        if (status != 1) {
            System.out.println("Unable to add deposit");
        }
        return status;
    }


    @Override
    public int deleteDeposit(Long deposit_id) {
        return depositRepository.delete(deposit_id);
    }

    @Override
    public List<Deposit> findAllDeposit() {
        return depositRepository.findAll();
    }

    @Override
    public List<Deposit> findDepositByUsername(String userName) {
        List<Deposit> deposits = new ArrayList<>();

        if (!userService.isValidUser(userName)) {
            System.out.println("username is not valid");
            return deposits;
        }
        deposits = depositRepository.findByUsername(userName);
        return deposits;
    }


}

