import { ACTION_TYPES } from '../constants/actionTypes';

const setUserProfile = (data) => ({
  type: ACTION_TYPES.APP.USER_PROFILE,
  data
});

const setCurrencies = (data) => ({
  type: ACTION_TYPES.APP.CURRENCIES,
  data
});

const setCategories = (data) => ({
  type: ACTION_TYPES.APP.CATEGORIES,
  data
});
const setUsernames = (data) => ({
  type: ACTION_TYPES.APP.USERNAMES,
  data
});

const setDeposits = (data) => ({
  type: ACTION_TYPES.APP.DEPOSITS,
  data
});
const setExpenses = (data) => ({
  type: ACTION_TYPES.APP.EXPENSES,
  data
});
const setHistory = (data) => ({
  type: ACTION_TYPES.APP.HISTORY,
  data
});
const setFeedbacks = (data) => ({
  type: ACTION_TYPES.APP.FEEDBACKS,
  data
});
const setBalance = (data) => ({
  type: ACTION_TYPES.APP.BALANCE,
  data
});

export {
  setUserProfile,
  setCurrencies,
  setCategories,
  setUsernames,
  setDeposits,
  setExpenses,
  setHistory,
  setFeedbacks,
  setBalance
};
