package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.Deposit;
import com.dbms.Expense.Management.Model.Expense;
import com.dbms.Expense.Management.Service.DepositService;
import com.dbms.Expense.Management.Service.IDepositService;
import com.dbms.Expense.Management.Service.IExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DepositController {

    @Autowired
    private IDepositService depositService; //service ka object

    @PostMapping("/addDeposit")
    public int saveDeposit(@RequestBody Deposit deposit) {
        return depositService.insertDeposit(deposit);
    }


    @DeleteMapping("/deleteDeposit/{deposit_id}")
    public int deleteDeposit(@PathVariable(value = "deposit_id") Long deposit_id) {
        return depositService.deleteDeposit(deposit_id);
    }


    @GetMapping("/findDepositByUsername/{user_name}")
    public List<Deposit> findDeposit(@PathVariable(value = "user_name") String user_name) {
        return depositService.findDepositByUsername(user_name);
    }


    @GetMapping("/findAllDeposit")
    public List<Deposit> getDeposit() {
        return depositService.findAllDeposit();
    }

}
