package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.Feedback;
import com.dbms.Expense.Management.Service.IFeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class FeedbackController {


    @Autowired
    private IFeedbackService feedbackService;

    @PostMapping("/addFeedback")
    public int addFeedback(@RequestBody Feedback feedback) {
        return feedbackService.addFeedback(feedback);
    }


// show only feedbacks, not query
// is_query 0 means false, it is a feedback , 1 means true it is a query

    @GetMapping("/getAllFeedback")
    public List<Feedback> getAllFeedback() {
        return feedbackService.getAllFeedback();
    }


    @GetMapping("/getAllQuery")
    public List<Feedback> getAllQuery() {
        return feedbackService.getAllQuery();
    }


    @DeleteMapping("/deleteFeedback/{feedback_id}")
    public int deleteCategory(@PathVariable(value = "feedback_id") int feedback_id) {
        return feedbackService.delete(feedback_id);
    }


}
