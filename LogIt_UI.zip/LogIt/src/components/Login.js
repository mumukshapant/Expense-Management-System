import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Alert } from "react-bootstrap";
import { Button } from "react-bootstrap";
import './Login.css';
import CreateUserModal from "../logitComponents/CreateUserModal";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { currenciesSelector } from "../redux/selectors/app";
import { setCategories, setCurrencies, setUsernames } from "../redux/actions/app";
import { fetchBalance } from "../redux/thunks/refresh.thunk";
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showCreatUserModal, setShowCreatUserModal] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();


  const fetchUsernames = async () => {
    try {
      const response = await axios.get('http://localhost:8080/getUsername');
      dispatch(setUsernames(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

  const fetchCurrencies = async () => {
    try {
      const response = await axios.get('http://localhost:8080/findAllCurrency');
      dispatch(setCurrencies(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:8080/findAllCategories');
      dispatch(setCategories(response?.data))
    } catch (error) {
      console.log(error, 'xyzxyz');
    }
  }

  useEffect(() => {
    fetchCurrencies();
    fetchCategories();
    fetchUsernames();
    fetchBalance();
  }, [])
  

  return (
    <>
      <div className="p-4 box loginCenterForm">
        <h3 className="mb-2 text-center">LogIt Login</h3>
        <span style={{fontSize:"14px", textAlign:'center'}}>Login in with your user id</span>
        {error && <Alert variant="danger">{error}</Alert>}
        <Link to="/emailsignup">
          <div className="d-grid gap-2 mt-4">
            <Button variant="success" type="Submit">
              Sign in
            </Button>
          </div>
        </Link>
        <div className="d-grid gap-2 mt-4">
          <Button variant="success" type="Submit" onClick={() => setShowCreatUserModal(true)}>
            Sign Up
          </Button>
        </div>
      </div>

      <CreateUserModal
        show={showCreatUserModal}
        onHide={() => setShowCreatUserModal(false)}
      />

    </>
  );
};

export default Login;
