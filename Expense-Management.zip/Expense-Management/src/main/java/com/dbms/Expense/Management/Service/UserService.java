package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.User;
import com.dbms.Expense.Management.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public int insertUser(User user) {
        if (isValidUser(user.getUserName())) {
            System.out.println("User already exists with the username! please choose another username");
            return -1;
        }
        return userRepository.insert(user);
    }

    @Override
    public User getUserInfo(String username) {
        if (!isValidUser(username)) {
            System.out.println("No User exists with the username: " + username);
            return null;
        }

        return userRepository.findByUserName(username);
    }

    @Override
    public int deleteUser(String username) {
        if (!isValidUser(username)) {
            System.out.println("No User exists with the username: " + username);
            return 0;
        }
        return userRepository.deleteByUserName(username);
    }


    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    public boolean isValidUser(String username) {
        return userRepository.userExists(username);
    }

    @Override
    public boolean updateUser(User user) {
        if (!isValidUser(user.getUserName())) {
            System.out.println("No User exists with the username: " + user.getUserName());
            return false;
        }
        userRepository.update(user);
        return true;
    }

    @Override
    public List<String> getUsername() {
        List<User> users = findAll();
        List<String> usernames = new ArrayList<>();
        for (User user : users
        ) {
            usernames.add(user.getUserName());
        }
        return usernames;
    }

    @Override
    public float getBalance(String username) {
        return userRepository.getUserBalance(username);
    }

}
