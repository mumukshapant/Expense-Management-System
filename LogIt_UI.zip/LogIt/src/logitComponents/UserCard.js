import { useState } from 'react';
import { Card, ListGroup, ListGroupItem, Badge, Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { setUserProfile } from '../redux/actions/app';
import { useDispatch, useSelector } from 'react-redux';
import { refreshData } from '../redux/thunks/refresh.thunk';
import { balanceSelector, balanceSelectore } from '../redux/selectors/app';

export default function UserCard(props) {
  const userBalance = useSelector(balanceSelector);

  console.log("user balance :" + userBalance)
  const [showModal, setShowModal] = useState(false);
  const [updatedUser, setUpdatedUser] = useState({...props.user});
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUpdatedUser(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleUpdate = async () => {
    try {
      const response = await axios.put(`http://localhost:8080/updateuser`, updatedUser);
      if(response?.data === 1) {
        setShowModal(false);
        refreshData();
      } else  {

      }
    } catch (error) {
      console.log(error)
    }

  };


  const handleDeleteSubmit = async() => {

    if (window.confirm("Are you sure you want to delete this user?")) {
      // props.onDeleteUser();
      console.log('called delete');
      try {
        const response = await axios.delete(`http://localhost:8080/deleteuser/${props.user.userName}`)
        console.log(response?.data);
        if(response?.data==1){
          
        navigate("/");
        props.fetchHistory()}
      } catch (error) {
        
      }
      navigate("/");
      dispatch(setUserProfile({}));
    }
    // props.onHide();
  };




  return (
    <Card>
      <Card.Header>User Information</Card.Header>
      <Card.Body>
        <ListGroup>
          <ListGroupItem>
            <strong>Username:</strong> {props.user.userName}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Name:</strong> {props.user.firstName} {props.user.lastName}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Date of Birth:</strong> {props.user.dateOfBirth}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Email:</strong> {props.user.emailId}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Gender:</strong> {props.user.gender}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Contact Number:</strong> {props.user.contactNumber}
          </ListGroupItem>
          <ListGroupItem>
            <strong>Domestic Currency:</strong> {props.user.domesticCurrency}
          </ListGroupItem>
        { !props.user.admin && <ListGroupItem>
  <strong>Wallet Balance:</strong>{" "}
  <span style={{ backgroundColor: "yellow", fontWeight: "bold" }}>
    {props.user.domesticCurrency} {userBalance}
  </span>
</ListGroupItem>}


        </ListGroup><br/>
        <Button variant="primary" onClick={() => setShowModal(true)}>
          Update User
        </Button>
      </Card.Body>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit User Information</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>


          <Form.Group controlId="formBasicFirst">
              <Form.Label>First Name:</Form.Label>
              <Form.Control 
                type="text"
                name="firstName"
                value={updatedUser.firstName}
                onChange={handleInputChange} />
            </Form.Group>

            <Form.Group controlId="formBasicLastName">
              <Form.Label>Last Name:</Form.Label>
              <Form.Control 
                type="text"
                name="lastName"
                value={updatedUser.lastName}
                onChange={handleInputChange} />
            </Form.Group>

            <Form.Group controlId="formBasicDateOfBirth">
              <Form.Label>Date of Birth:</Form.Label>
              <Form.Control 
                type="date"
                name="dateOfBirth"
                value={updatedUser.dateOfBirth}
                onChange={handleInputChange} />
            </Form.Group>

            <Form.Group controlId="formBasicEmailId">
              <Form.Label>Email Id:</Form.Label>
              <Form.Control 
                type="email"
                name="emailId"
                value={updatedUser.emailId}
                onChange={handleInputChange} />
            </Form.Group>

            <Form.Group controlId="formBasicPhoneNumber">
              <Form.Label>Phone Number:</Form.Label>
              <Form.Control 
                type="text"
                name="contactNumber"
                value={updatedUser.contactNumber}
                onChange={handleInputChange} />
            </Form.Group>
            <Form.Group controlId="formBasicCurrency">
              <Form.Label>Domestic Currency:</Form.Label>
              <Form.Control 
                as="select"
                name="domesticCurrency"
                value={updatedUser.domesticCurrency}
                onChange={handleInputChange}>
                 {props.currencies.map((currency) => (
                  <option key={currency.abbreviation} value={currency.abbreviation}>
                    {currency.abbreviation}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowModal(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate} variant="primary">
                Save Changes
              </Button>
              <Button variant="danger" onClick={handleDeleteSubmit}>
                Delete User
              </Button>
            </Modal.Footer>
          </Form>
        </Modal.Body>
      </Modal>
    </Card>
  );
}
