import React, { useState, useEffect } from "react";
import { Modal, Form, Button } from "react-bootstrap";
import { useSelector } from "react-redux";
import { categoriesSelector, currenciesSelector, userProfileSelector } from "../redux/selectors/app";
import axios from "axios";
import { refreshData } from "../redux/thunks/refresh.thunk";

const ExpenseModal = (props) => {
  const [showModal, setShowModal] = useState(false);
  const [userNames, setUserNames] = useState('');
  const userProfile = useSelector(userProfileSelector);
  const [expenseData, setExpenseData] = useState({
    amount: 0,
    category: "",
    creation_date: new Date(),
    currency: "",
    description: "",
  });
  const categories = useSelector(categoriesSelector);
  const currencies = useSelector(currenciesSelector);;

  const handleExpenseChange = (event) => {
    const { name, value } = event.target;
    setExpenseData({ ...expenseData, [name]: value });
  };

  const handleSubmit = async () => {
    // event.preventDefault();
    try {
      const enteredUsernames = userNames.split(',');
      
      const response = await axios.post(`http://localhost:8080/insertExpense`, {
        ...expenseData,
        usernames: [
          userProfile?.userName,
          ...(userNames ? userNames.split(',') : [])
        ]        
       
      });
      console.log(response, 'xyzxyz');
      if(response?.data == 1) {
        handleClose();
        refreshData();
      } else {
        // show alert
      }
    } catch (error) {
      
    }
  };

  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Add Expense
      </Button>

      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header closeButton> 
          <Modal.Title>Add Expense</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="amount">
              <Form.Label>Amount</Form.Label>
              <Form.Control
                type="number"
                name="amount"
                value={expenseData.amount}
                onChange={handleExpenseChange}
                required
              />
            </Form.Group>
            <Form.Group controlId="category">
              <Form.Label>Category</Form.Label>
              <Form.Control
                as="select"
                name="category"
                value={expenseData.category}
                onChange={handleExpenseChange}
                required
              >
                <option value="">Select a category</option>
                {categories!=null && categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
            <Form.Group controlId="description">
              <Form.Label>Description</Form.Label>
              <Form.Control
                type="text"
                name="description"
                value={expenseData.description}
                onChange={handleExpenseChange}
                required
              />
            </Form.Group>
            <Form.Group controlId="currency">
              <Form.Label>Currency</Form.Label>
              <Form.Control
                as="select"
                name="currency"
                value={expenseData.currency}
                onChange={handleExpenseChange}
                required
              >
                <option value="">Select a currency</option>
                {currencies!=null && currencies.map((currency) => (
                  <option key={currency.abbreviation} value={currency.abbreviation}>
                    {currency.abbreviation}
                  </option>
                ))}
              </Form.Control>
            </Form.Group><br/>
            <Form.Group controlId="usernames">
              <Form.Label>Split expense ? Add usernames:</Form.Label>
              <Form.Control
                type="text"
                name="usernames"
                value={userNames}
                onChange={(e) => setUserNames(e?.target?.value)}
                required
              />
            </Form.Group><br/>
            <Button variant="primary" onClick={handleSubmit}>
              Submit
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default ExpenseModal;
