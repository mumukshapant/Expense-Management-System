package com.dbms.Expense.Management.Model;


public class Currency {
    private String currency_name;
    private String abbreviation;

    public String getCurrency_name() {
        return currency_name;
    }

    public Currency() {
    }

    public Currency(String currency_name, String abbreviation, Float rate) {
        this.currency_name = currency_name;
        this.abbreviation = abbreviation;
        this.rate = rate;
    }

    public void setCurrency_name(String currency_name) {
        this.currency_name = currency_name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public Float getRate() {
        return rate;
    }

    public void setRate(Float rate) {
        this.rate = rate;
    }

    private Float rate;
}
