import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Alert } from "react-bootstrap";
import { Button } from "react-bootstrap";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { AuthService, isValidToken } from "../service/AuthService";
import { APICallStatus } from "../constants";

const PhoneSignUp = () => {
  const [error, setError] = useState("");
  const [number, setNumber] = useState("");
  const [flag, setFlag] = useState(false);
  const [otp, setOtp] = useState("");
  const [result, setResult] = useState("");
  const navigate = useNavigate();

  const getOtp = async (e) => {
    e.preventDefault();
    console.log(number);
    setError("");
    if (number === "" || number === undefined)
      return setError("Please enter a valid phone number!");
    try {
      const adminNumbers = ["+918114486673", "+917550250062", "+917780198146"];
      if(!adminNumbers?.includes(number)) {
        return setError("You are not authorized to access the portal");
      }
      const response = await AuthService.phoneSignin(number);
      setResult(response);
      if(response?.status === APICallStatus.SUCCESS) {
        setFlag(true);
      }
    } catch (err) {
      console.log(error, '123')
      setError(err.message);
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    setError("");
    if (otp === "" || otp === null) return;
    try {
      const response = await AuthService.verifyPhoneOtp(otp, result?.verificationId);
      if(response?.status === APICallStatus.SUCCESS)
        navigate("/home");
    } catch (err) {
      console.log(error)
      setError(err.message);
    }
  };

  return (
    <>
      <div className="p-4 loginCenterForm">
      {/* <h3 className="mb-3 text-center">Rive Admin Login</h3> */}
        <span style={{fontSize:"14px"}}>Please enter your registered mobile number</span>
        {error && <Alert variant="danger">{error}</Alert>}
        <Form onSubmit={getOtp} style={{ display: !flag ? "block" : "none", marginTop:"20px" }}>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <PhoneInput
              defaultCountry="IN"
              value={number}
              onChange={setNumber}
              placeholder="Enter Phone Number"
            />
            <div id="recaptcha-container"></div>
          </Form.Group>
          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary">
              Send Otp
            </Button>
          </div>
        </Form>

        <Form onSubmit={verifyOtp} style={{ display: flag ? "block" : "none" }}>
          <Form.Group className="mb-3" controlId="formBasicOtp">
            <Form.Control
              type="otp"
              placeholder="Enter OTP"
              onChange={(e) => setOtp(e.target.value)}
            />
          </Form.Group>
          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary">
              Verify
            </Button>
          </div>
        </Form>
      </div>
    </>
  );
};

export default PhoneSignUp;
