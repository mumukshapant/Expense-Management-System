import axios from 'axios';
import React, { useState } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import { refreshData } from '../redux/thunks/refresh.thunk';

const CategoryTable = ({ categories, onUpdate, onDelete, onAdd }) => {
  const [showModal, setShowModal] = useState(false);
  const [editedCategory, setEditedCategory] = useState(null);
  const [newCategory, setNewCategory] = useState({});

  const handleShowModal = (category) => {
    setEditedCategory(category);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditedCategory(null);
  };

  const handleUpdate = async () => {

    console.log(editedCategory,newCategory )
  
    const response = await axios.put(`http://localhost:8080/updatecategory?NewCategoryName=${newCategory.newCategory}`+`&OldCategoryName=${editedCategory}`);
    if(response?.data == 1) {
        handleCloseModal();
        refreshData();
    } else {
        // show alert
    }
  };

  const handleDelete = async (id) => {
    console.log("Deleted Category :" +id)
    const response = await axios.delete(`http://localhost:8080/deleteCategory/${id}`);
    if(response?.data == 1) {
        handleCloseModal();
        refreshData();
    } else {
        // show alert
    }
  };

  const handleAdd = async () => {
    try {
      console.log(newCategory);
        const response = await axios.post(`http://localhost:8080/addCategory/${newCategory.newCategory}`);
        console.log(response, 'xyzxyz')
        if(response?.data === 1) {
            handleCloseModal();
            refreshData();
        } else {
          // show alert
        }
      } catch (error) {
        console.log('An error occurred while adding the currency.', error);
      }
    };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setNewCategory({ ...newCategory, [name]: value });
  };

  return (
    <>
    <Button variant="primary" onClick={() => setShowModal(true)}>
        Add Category
      </Button><br/>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Category</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {
          categories.map((category) => (
            <tr key={category.id}>
              <td>{category}</td>
              <td>
                <Button variant="primary" onClick={() => handleShowModal(category)}>
                  Update
                </Button>{' '}
                <Button variant="danger" onClick={() => handleDelete(category)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>


      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>{editedCategory ? 'Update Category' : 'Add Category'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="newCategory">
            {!editedCategory && <Form.Label>Enter Category to Insert</Form.Label>}
            {editedCategory && <Form.Label>New Name</Form.Label>}
              <Form.Control
                type="text"
                name="newCategory"
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            {editedCategory && (<Form.Group controlId="oldCategory">
              <Form.Label>Old Name</Form.Label>
              <Form.Control
                type="text"
                defaultValue={editedCategory}
                name="oldCategory"
                onChange={handleInputChange}
                required
                disabled={editedCategory ? true : false}
              />
            </Form.Group>)}
          
            <Button variant="primary" onClick={editedCategory ? handleUpdate : handleAdd}> Save Changes</Button>
</Form></Modal.Body></Modal>
</>);
}
export default CategoryTable;