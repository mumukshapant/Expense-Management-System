import axios from "axios";
import React, { useEffect, useState } from "react";
import AddFeedbackModal from "./AddFeedbackModal";
import { Button } from "react-bootstrap";
import { fetchFeedbacks } from "../redux/thunks/refresh.thunk";
import { useSearchParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { feedbacksSelector } from "../redux/selectors/app";

const FeedbackCard = () => {

  
  const [showAddModal, setShowAddModal] = useState(false);
  
  const handleCloseAddModal = () => setShowAddModal(false);
  const handleShowAddModal = () => setShowAddModal(true);

  const handleAddFeedback = (newFeedback) => {
    // Add logic to add the new feedback to the feedbacks array
    console.log(newFeedback);
  }
    const feedbacks = useSelector(feedbacksSelector);


    
  console.log(feedbacks)
    useEffect(() => {
        fetchFeedbacks();
    }, [])
   
    // const handleDelete = async (id) => {
    //   try {
    //     const response = await axios.delete(`http://localhost:8080/deleteExpense/${id}`)
    //     console.log(response.data)
    //     if(response?.data==1){
    //       alert('Expense deleted successfully!');
    //       setExpenses(expenses.filter((expense) => expense.id !== id));
    //     }
    //     props.fetchHistory();
    //     fetchExpenses();
    //   } catch (error) {
        
    //   }
    // }
  return (
    <>
  <Button onClick={handleShowAddModal}>Add Feedback</Button><br/>
      <AddFeedbackModal
      fetchFeedbacks ={fetchFeedbacks}
        show={showAddModal}
        handleClose={handleCloseAddModal}
        handleAddFeedback={handleAddFeedback}
      /><br></br>
      {feedbacks.map((feedback) => (
        <div key={feedback.feedback_id} className="card mb-3">
          <div className="card-body"  style={{backgroundColor:"#BFCCB5"}}>
            <h5 className="card-title">{feedback.user_name}</h5>
            <h6 className="card-subtitle mb-2 text-muted">
              {feedback.user_email_address}
            </h6>
            <p className="card-text">{feedback.description}</p>
            <p className="card-text">
              <small className="text-muted">{feedback.creation_date}</small>
            </p>
          </div>
        </div>
      ))}
       
    </>
  );
};

export default FeedbackCard;
