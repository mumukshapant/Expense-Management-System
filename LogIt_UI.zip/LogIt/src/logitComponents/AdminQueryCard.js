import axios from 'axios';
import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';



const AdminQueryCards = (props) => {

  const handleDelete = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/deleteFeedback/${id}`)
      if(response?.data==1){
        console.log("Query deleted")
      }
      props.fetchQueries();
    } catch (error) {
      
    }
  }
  return (
    <Row className="mx-0">
        <h2>Here is the list of Queries from users:</h2>
      {props.queryList.map((feedback) => (
        <Col key={feedback} sm={12} md={6} lg={4} className="p-3">
          <Card >
            <Card.Body style={{backgroundColor:"#BBD6B8"}}>
              <Card.Title>
                <strong>Username:</strong> {feedback.user_name}
              </Card.Title>
              <Card.Text>
                {feedback.user_email_address}
              </Card.Text>
             
              <Card.Text><strong>Description :</strong><br/>
             {feedback.description}
              </Card.Text>

              <Card.Text><strong>Creation Date :</strong><br/>
             {feedback.creation_date}
              </Card.Text>
             
        <button onClick={() => handleDelete(feedback.feedback_id)}>Delete</button>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default AdminQueryCards;
