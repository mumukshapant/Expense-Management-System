import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Alert, FloatingLabel } from "react-bootstrap";
import { Button } from "react-bootstrap";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { AuthService, isValidToken } from "../service/AuthService";
import { APICallStatus } from "../constants";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setUserProfile } from "../redux/actions/app";
import { usernamesSelector } from "../redux/selectors/app";

const EmailSignUp = () => {
  const [error, setError] = useState("");
  const [userId, setUserId] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const usernames = useSelector(usernamesSelector);
  const loginUsingUsername = async () => {
    // login api call here
    // if userdetails fetched call navigate('/userDashboard') for users and navigate('/adminDashboard') for admin
    try {
      if(!usernames.includes(userId)){
        alert("Not valid username!");

      }
      const response = await axios.get(`http://localhost:8080/getuser/${userId}`);
      console.log(response?.data);
      const userProfile = response?.data;
      dispatch(setUserProfile(userProfile));
      if(userProfile?.admin) {
        navigate('/adminDashboard')
      } else {
        navigate('/userDashboard')
      }
    } catch (error) {
      
    }
  }

  return (
    <>

      <div className="p-4 loginCenterForm">
      <h1 style={{ fontSize: '3rem', marginBottom: '2rem', color: '#1a1a1a' }}>Welcome to LogIt!</h1>
        <div style={{textAlign: 'left', display: "block"}}>
          <span style={{fontSize:"14px"}}>Please enter your username</span>
          {error && <Alert variant="danger">{error}</Alert>}
          <FloatingLabel
            controlId="floatingInput"
            label="Username"
            className="my-3"
          >
            <Form.Control type="text" value={userId} placeholder="user id here" onChange={(e) => setUserId(e?.target?.value)}/>
          </FloatingLabel>

          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary" onClick={loginUsingUsername}>
              Login
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default EmailSignUp;
