import React, { useEffect, useState } from "react";
import { Container, Modal, Row } from "react-bootstrap";
import { useNavigate } from "react-router";
import axios from 'axios';
import { useSelector } from "react-redux";
import { categoriesSelector, currenciesSelector, userProfileSelector } from "../redux/selectors/app";
import logit from '../logitComponents/LogitConstants';
import UserCard from "../logitComponents/UserCard";
import CurrencyTable from "../logitComponents/CurrencyTable";
import CategoryTable from "../logitComponents/CategoryTable";
import UserCardList from "../logitComponents/UserCardList";
import AdminFeedbackCards from "../logitComponents/AdminFeedbackCards";
import AdminQueryCards from "../logitComponents/AdminQueryCard";


const AdminHome = () => {
  const [showUpdateModal, setUpdateModal] = useState(false);
  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const navigate = useNavigate();
  const userProfile = useSelector(userProfileSelector);


  const tempList = [];

  const [showCreatUserModal, setShowCreatUserModal] = useState(false);

  const handleCreateUser = (userData) => {
    // Do something with the user data
  };

  const handleCloseCreatUserModal = () => {
    setShowCreatUserModal(false);
  };

  const handleOpenCreatUserModal = () => {
    setShowCreatUserModal(true);
  };

  const [history, setHistory] = useState([]);
  const [deposits, setDeposits] = useState(logit.deposits);
  const [expenses, setExpenses] = useState(logit.expenses);
  const categories = useSelector(categoriesSelector);
  const currencies =  useSelector(currenciesSelector);
  const [usersList, setUsersList] = useState([]);
  const user = useSelector(userProfileSelector)

  const [feedbackList, setFeedbackList] = useState([]);
  const [queryList, setQueryList] = useState([]);

  const fetchHistory = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/findAllHistory/${user?.userName}`);
      setHistory(response?.data);
    } catch (error) {
      
    }
  }
  const fetchUserList = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/getAll`);
      setUsersList(response?.data);
    } catch (error) {
      
    }
  }

  const fetchFeedbacks = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/getAllFeedback`);
      console.log(response?.data)
      setFeedbackList(response?.data);
    } catch (error) {
      
    }
  } 
   const fetchQueries = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/getAllQuery`);
      setQueryList(response?.data);
    } catch (error) {
      
    }
  }

  useEffect(() => {
    fetchHistory();
    fetchUserList();
    fetchFeedbacks();
    fetchQueries();
  }, [])


  return (
    <Container style={{ paddingTop: "4%" }}>
    <h1>Welcome Admin!</h1>
    <div className="row">
      <div className="col-md-9">
        <UserCardList fetchUserList={fetchUserList} users={usersList}/>
      </div>
      <div className="col-md-3">
        <div className="row">
          <div className="col-md-12">
            <UserCard user={user} currencies={currencies} />
          </div>
          <div className="col-md-12">
            {/* <FeedbackList /> */}
          </div>
        </div>
      </div>
    </div><br/>
    <div className="row">
      <div className="col-md-6">
        <h2>Manage Expense Categories:</h2><br></br>
        <CategoryTable categories={categories}></CategoryTable>
      </div>
      <div className="col-md-6">
      <h2>Manage Currencies:</h2><br></br>
        <CurrencyTable currencies={currencies}></CurrencyTable>
      </div>
    </div><br/>
    <div className="row">
      <div className="col-md-6">
        <h2>Manage Feedbacks:</h2><br></br>
        <AdminFeedbackCards fetchFeedbacks={fetchFeedbacks} feedbackList={feedbackList}></AdminFeedbackCards>
      </div>
      <div className="col-md-6">
      <h2>Manage Queries:</h2><br></br>
        <AdminQueryCards fetchQueries={fetchQueries} queryList={queryList}></AdminQueryCards>
      </div>
    </div>
    
  </Container>
  
  );
};

export default AdminHome;
