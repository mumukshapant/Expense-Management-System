import React,{useEffect, useState} from 'react'
import './cards.css'
import { Card, Col, Row, Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { depositsSelector, userProfileSelector } from '../redux/selectors/app';
import { fetchDeposits, refreshData } from '../redux/thunks/refresh.thunk';

export default function DepositCards(props) {  
  const userProfile = useSelector(userProfileSelector);
  // const [deposits, setDeposits ] = useState([]);
  const deposits = useSelector(depositsSelector);

  // const fetchDeposits = async () => {
  //   try {
  //     const response = await axios.get(`http://localhost:8080/findDepositByUsername/${userProfile?.userName}`)
  //     setDeposits(response?.data);

  //   } catch (error) {
      
  //   }
  // }

  useEffect(() => {
    fetchDeposits();
  }, [])
 
  const handleDelete = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/deleteDeposit/${id}`)
      console.log(response?.data);
      if(response?.data==1){
        alert('Deposit deleted successfully!');
        // setDeposits(deposits.filter((deposit) => deposit.id !== id));
        refreshData();
      }
      // props.fetchHistory()
      // fetchDeposits()
    } catch (error) {
      
    }
  }
return(
<Container className='appContainer '>
    <Row xs={1} md={3} className='pt-5'>
        {
            deposits.map( deposit=>  
            
            <Col className='my-2'>
           <Card style={{backgroundColor: ""}} className=" bg-success">
      <Card.Body className="text-dark">
        <Card.Title>Deposit Details</Card.Title>
        <Card.Text>Amount: {deposit.currency} {deposit.amount} </Card.Text>
        <Card.Text>Description: {deposit.description}</Card.Text>
        <Card.Text>Deposit Date: {deposit.deposit_date}</Card.Text> 
        <button onClick={() => handleDelete(deposit?.deposit_id)}>Delete</button>
      </Card.Body>
    </Card>
         </Col>)
        }
        
    </Row>

</Container>)
}
