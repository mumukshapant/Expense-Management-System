import { useState } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';

const allCategories = [
  "Charity/Donations",
  "Clothing",
  "Deposit",
  "Education",
  "Electronics",
  "Entertainment",
  "Food",
  "Health care",
  "Housing",
  "Personal care",
  "Savings and investment",
  "Shopping",
  "string",
  "Transport"
];

const MyTable = () => {
  const [tableData, setTableData] = useState(allCategories);
  const [showModal, setShowModal] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  const handleDeleteRow = (index) => {
    const newData = tableData.filter((item, i) => i !== index);
    setTableData(newData);
  };

  const handleUpdateRow = (index, newName) => {
    const newData = [...tableData];
    newData[index] = newName;
    setTableData(newData);
  };

  const handleAddCategory = () => {
    if (newCategoryName.trim() !== '') {
      const newData = [...tableData];
      newData.push(newCategoryName);
      setTableData(newData);
      setNewCategoryName('');
      setShowModal(false);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setNewCategoryName('');
  };

  return (
    <>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Category</th>
            <th>Update</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((category, index) => (
            <tr key={index}>
              <td>{category}</td>
              <td>
                <Button
                  variant="primary"
                  onClick={() => {
                    const newName = prompt('Enter new name for category:');
                    if (newName) {
                      handleUpdateRow(index, newName);
                    }
                  }}
                >
                  Update
                </Button>
              </td>
              <td>
                <Button
                  variant="danger"
                  onClick={() => handleDeleteRow(index)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      <Button variant="primary" onClick={() => setShowModal(true)}>
        Add Category
      </Button>
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Category</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group>
            <Form.Label>Category Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter category name"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddCategory}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default MyTable;
