import axios from 'axios';
import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';



const UserCardList = (props) => {

  const handleDelete = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/deleteuser/${id}`)
      console.log(response?.data);
      props.fetchUserList();
    } catch (error) {
      
    }
  }
  return (
    <Row className="mx-0">
        <h2>Here is the list of system users:</h2>
      {props.users.map((user, index) => (!user.admin&&
        <Col key={index} sm={12} md={6} lg={4} className="p-3">
          <Card style={{backgroundColor: user.gender ==='MALE' ? '#B9EDDD' : '#FCC8D1'}}>
            <Card.Body>
              <Card.Title>{`${user.firstName} ${user.lastName}`}</Card.Title>
              <Card.Text>
                <strong>Username:</strong> {user.userName}
              </Card.Text>
              <Card.Text>
                <strong>Date of Birth:</strong> {user.dateOfBirth}
              </Card.Text>
              <Card.Text>
                <strong>Email:</strong> {user.emailId}
              </Card.Text>
              <Card.Text>
                <strong>Gender:</strong> {user.gender}
              </Card.Text>
              <Card.Text>
                <strong>Contact Number:</strong> {user.contactNumber}
              </Card.Text>
              <Card.Text>
                <strong>Domestic Currency:</strong> {user.domesticCurrency}
              </Card.Text>
        <button onClick={() => handleDelete(user?.userName)}>Delete</button>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default UserCardList;
