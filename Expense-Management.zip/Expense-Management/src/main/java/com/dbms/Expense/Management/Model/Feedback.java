package com.dbms.Expense.Management.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


public class Feedback {
    private long feedback_id;
    private boolean query;
    private String description;
    private Date creation_date;
    private String user_name; //userName in USER model
    private String user_email_address; // emailId in USER model

    public long getFeedback_id() {
        return feedback_id;
    }

    public void setFeedback_id(long feedback_id) {
        this.feedback_id = feedback_id;
    }

    public boolean isQuery() {
        return query;
    }

    public void setQuery(boolean query) {
        this.query = query;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(Date creation_date) {
        this.creation_date = creation_date;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_email_address() {
        return user_email_address;
    }

    public void setUser_email_address(String user_email_address) {
        this.user_email_address = user_email_address;
    }

    public Feedback(long feedback_id, boolean query, String description, Date creation_date, String user_name, String user_email_address) {
        this.feedback_id = feedback_id;
        this.query = query;
        this.description = description;
        this.creation_date = creation_date;
        this.user_name = user_name;
        this.user_email_address = user_email_address;
    }

    public Feedback() {
    }
};



