import React,{useState} from 'react'
import './cards.css'
import { Card, Col, Row, Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';

export default function HistoryCards(props) {    
console.log(props)
return(
<Container className='appContainer '>
    <Row xs={1} md={3} className='pt-5'>
        {
            props.history.map( expense=> 
            
              <Col className='my-2'>
           <Card style={{backgroundColor: expense.history_type ==='Expense' ? '#E4DCCF' : '#F9F5EB'}}>
      <Card.Body className="text-dark">
        <Card.Title>{expense.history_type}</Card.Title>
       {expense.shared_count==1 &&<Card.Text>Amount: {expense.currency} {expense.amount} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Total Amount: {expense.currency} {expense.amount} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Per Person Amount: {expense.currency} {expense.amount_per_user} </Card.Text>}
       {expense.shared_count>1 &&<Card.Text>Split parts count: {expense.shared_count}</Card.Text>}
        <Card.Text>Description: {expense.description}</Card.Text>
        <Card.Text>Creation Date: {expense.creation_date}</Card.Text> 
        <Card.Text>Deletion Date: {expense.deletion_date}</Card.Text> 
        {expense.category && <Card.Text>Expense Category: {expense.category}</Card.Text> }
        <Card.Text>History Type: {expense.history_type}</Card.Text> 
    
    
      </Card.Body>
    </Card>
         </Col>
              )
            
        }
        
    </Row>

</Container>)
}
