import { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

export default function DeleteUserModal(props) {
  const [userData, setUserData] = useState({
    userId: props.userId,
  });

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (window.confirm("Are you sure you want to delete this user?")) {
      props.onDeleteUser(userData);
    }
    props.onHide();
  };

  return (
    <Modal {...props} centered>
      <Modal.Header closeButton>
        <Modal.Title>Delete User</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleFormSubmit}>
          <Form.Group controlId="userId">
            <Form.Label>User ID</Form.Label>
            <Form.Control
              type="text"
              name="userId"
              value={userData.userId}
              readOnly
            />
          </Form.Group>
          <Button type="submit" variant="danger">
            Delete User
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
}
