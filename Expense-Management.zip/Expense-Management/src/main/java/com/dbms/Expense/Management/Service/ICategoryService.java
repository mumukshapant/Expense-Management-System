package com.dbms.Expense.Management.Service;

import java.util.List;

public interface ICategoryService {
    public int addCategory(String category_name);

    public int delete(String category);

    public List<String> findAllCategories();

    public int addCategoryList(List<String> categoryName);

    int updateCategory(String oldCategoryName, String newCategoryName);
}
