package com.dbms.Expense.Management.Service;

import com.dbms.Expense.Management.Model.Currency;
import com.dbms.Expense.Management.Model.Deposit;

import java.util.List;

public interface ICurrencyService {

    public int insertCurrency(Currency currency);

    public int deleteCurrency(String abbreviation);

    public Currency findCurrency(String abbreviation);

    public List<Currency> findAllCurrency();

    public boolean currencyExists(String abbreviation);

    int updateCurrency(Currency currency);

}
