package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.User;
import com.dbms.Expense.Management.Service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private IUserService userService;

    @GetMapping("/getAll")
    public List<User> getUsers() {
        return userService.findAll();
    }

    @GetMapping("/getuser/{username}")
    public User getUser(@PathVariable(value = "username") String username) {
        return userService.getUserInfo(username);
    }

    @PostMapping("/adduser")
    public int saveUser(@RequestBody User user) {
        return userService.insertUser(user);
    }

    @DeleteMapping("/deleteuser/{username}")
    public int deleteUser(@PathVariable(value = "username") String username) {
        return userService.deleteUser(username);
    }

    @GetMapping("/validateuser/{username}")
    public boolean validateUser(@PathVariable(value = "username") String username) {
        return userService.isValidUser(username);
    }

    @PutMapping("/updateuser")
    public int update(@RequestBody User user) {
        boolean response = userService.updateUser(user);
        return response == true ? 1 : 0;
    }

    @GetMapping("/getUsername")
    public List<String> getUsername() {
        return
                userService.getUsername();
    }


    @GetMapping("/getuserbalance/{username}")
    public float getBalance(@PathVariable(value = "username") String username) {
        return userService.getBalance(username);
    }

}
