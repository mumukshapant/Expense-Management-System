import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { useSelector } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import { userProfileSelector } from '../redux/selectors/app';
import axios from 'axios';
import { refreshData } from '../redux/thunks/refresh.thunk';

const DepositModal = (props) => {
  const userProfile = useSelector(userProfileSelector);
  
  const [formData, setFormData] = useState({
    amount: '',
    currency: '',
    deposit_date: '',
    description: '',
    user_name: userProfile?.userName,
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post(`http://localhost:8080/addDeposit`, formData);
      console.log(response, 'xyzxyz')
      if(response?.data === 1) {
        props.onHide();
        refreshData();
      } else {
        // show alert
      }
    } catch (error) {
      console.log('An error occurred while adding the deposit.', error);
    }
  };
  

  return (
    <Modal show={props.show} onHide={props.onHide}>
      <Modal.Header closeButton>
        <Modal.Title>Add Deposit</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <form >
          <div className="form-group">
            <label>Amount:</label>
            <input
              type="number"
              name="amount"
              className="form-control"
              value={formData.amount}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
  <label>Currency:</label>
  <select
    name="currency"
    className="form-control"
    value={formData.currency}
    onChange={handleInputChange}
    required
  >
    <option value="">Select a currency</option>
    {props.currencies.map(currency => (
      <option key={currency.abbreviation} value={currency.abbreviation}>
        {currency.abbreviation}
      </option>
    ))}
  </select>
</div>
          <div className="form-group">
            <label>Deposit Date:</label>
            <input
              type="date"
              name="deposit_date"
              className="form-control"
              value={formData.deposit_date}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <label>Description:</label>
            <input
              type="text"
              name="description"
              className="form-control"
              value={formData.description}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <label>User Name:</label>
            <input
              type="text"
              name="user_name"
              className="form-control"
              value={formData.user_name}
              onChange={handleInputChange}
              disabled
            />
          </div><br/>
          <Button onClick={handleSubmit}>Add Deposit</Button>
        </form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={props.onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default DepositModal;
