package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.Expense;
import com.dbms.Expense.Management.Model.ExpensePerUserModel;
import com.dbms.Expense.Management.Model.InsertExpenseModel;
import com.dbms.Expense.Management.Model.User;
import com.dbms.Expense.Management.Service.ExpenseService;
import com.dbms.Expense.Management.Service.IExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ExpenseController {

    @Autowired
    private IExpenseService expenseService;


    @DeleteMapping("/deleteExpense/{expense_id}")
    public int deleteExpense(@PathVariable(value = "expense_id") Long expense_id) {
        return expenseService.deleteExpense(expense_id);
    }


    @GetMapping("/findExpense/{expense_id}")
    public Expense findExpense(@PathVariable(value = "expense_id") Long expense_id) {
        return expenseService.findExpense(expense_id);
    }


    @GetMapping("/findAllExpense")
    public List<Expense> getExpense() {
        return expenseService.findAllExpense();
    }


    @PostMapping("/insertExpense")
    public int insertExpense(@RequestBody InsertExpenseModel expense) {
        return expenseService.insertExpense(expense);
    }

    @GetMapping("/findExpenseByUsername/{username}")
    public List<ExpensePerUserModel> findExpenseByUsername(@PathVariable(value = "username") String username) {
        return expenseService.findExpenseByUsername(username);
    }


}
