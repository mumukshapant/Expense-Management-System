package com.dbms.Expense.Management.Repository;

import com.dbms.Expense.Management.Model.Currency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class CurrencyRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;


    class CurrencyRowMapper implements RowMapper<Currency> {

        @Override
        public Currency mapRow(ResultSet rs, int rowNum) throws SQLException {
            Currency currency = new Currency();

            currency.setCurrency_name(rs.getString("currency_name"));
            currency.setAbbreviation(rs.getString("abbreviation"));
            currency.setRate(rs.getFloat("rate"));

            return currency;
        }

    }


    public int add(Currency currency) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("create_currency");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("currency_name", currency.getCurrency_name())
                .addValue("abbreviation", currency.getAbbreviation())
                .addValue("rate", currency.getRate());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }


    public int delete(String abbreviation) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("delete_currency");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("abb", abbreviation);
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }

    public Currency find(String abbreviation) {
        try {
            return jdbcTemplate.queryForObject("SELECT * FROM currency WHERE abbreviation = ?", new Object[]{abbreviation},
                    (rs, rowNum) -> new Currency(
                            rs.getString("currency_name"),
                            rs.getString("abbreviation"),
                            rs.getFloat("rate")

                    ));

        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return null;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public List<Currency> findAllCurrency() {
        return jdbcTemplate.query("select * from currency", new CurrencyRowMapper());
    }

    public boolean currencyExists(String abbreviation) {
        String sql = "SELECT COUNT(*) FROM currency WHERE abbreviation = ?";
        Integer count = jdbcTemplate.queryForObject(
                sql, new Object[]{abbreviation}, Integer.class);
        return count != null && count > 0;
    }


    public int update(Currency currency) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("update_currency");

        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue("newCurrencyName", currency.getCurrency_name())
                .addValue("abb", currency.getAbbreviation())
                .addValue("newRate", currency.getRate());
        try {
            Map<String, Object> out = jdbcCall.execute(inParams);

            int rowsAffected = (Integer) out.get("rowsAffected");

            return rowsAffected;
        } catch (DataAccessException e) {

            System.err.println("Error accessing database: " + e.getMessage());
            return -1;
        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());
            return -1;
        }
    }


}
