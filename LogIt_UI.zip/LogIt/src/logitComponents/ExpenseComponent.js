import React, { useState } from 'react';
import { Button } from 'react-bootstrap';
import ExpenseModal from './ExpenseModal';

const ExpenseComponent = (props) => {
  const [showModal, setShowModal] = useState(false);
  const handleAddExpense = (expense) => {
    console.log('Expense added:', expense);
  };

  return (
    <>
      <Button onClick={() => setShowModal(true)}>Add Expense</Button>
      <ExpenseModal
        show={showModal}
        onHide={() => setShowModal(false)}
        onClick={handleAddExpense}
        categories ={props.categories}
        currencies = {props.currencies}
      />
    </>
  );
};

export default ExpenseComponent;
