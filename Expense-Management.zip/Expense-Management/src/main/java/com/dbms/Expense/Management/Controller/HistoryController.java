package com.dbms.Expense.Management.Controller;

import com.dbms.Expense.Management.Model.LogitHistory;
import com.dbms.Expense.Management.Service.IDepositService;
import com.dbms.Expense.Management.Service.IHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class HistoryController {

    @Autowired
    private IHistoryService historyService;


    @GetMapping("/findAllHistory/{username}")
    public List<LogitHistory> getLogitHistoryByUsername(@PathVariable(value = "username") String username) {
        return historyService.findHistoryByUsername(username);
    }

}
