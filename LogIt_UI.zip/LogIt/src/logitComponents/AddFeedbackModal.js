import { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { useSelector } from 'react-redux';
import { userProfileSelector } from '../redux/selectors/app';
import axios from 'axios';
import { refreshData } from '../redux/thunks/refresh.thunk';

export default function AddFeedbackModal({ props,show, handleClose, handleAddFeedback ,fetchFeedbacks}) {
  const userProfile = useSelector(userProfileSelector);

  
const [feedback, setFeedback] = useState({
    query: false,
    description: '',
    creation_date: new Date().toISOString(),
    user_name: userProfile?.userName,
    user_email_address: userProfile?.emailId
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if(name === 'query') {
      setFeedback(prevFeedback => ({
        ...prevFeedback,
        [name]: value === 'true' ? true : false,
      }));
    } else {
      setFeedback(prevFeedback => ({
        ...prevFeedback,
        [name]: value
      }));
    }
  }

  const handleSubmit = async () => {
    try {
      console.log(feedback)
      const response = await axios.post(`http://localhost:8080/addFeedback`, feedback);
      console.log(response, 'xyzxyz')
      if(response?.data === 1) {
        console.log(response?.data)
        refreshData()
        handleClose()
      } else {
        // show alert
      }
    } catch (error) {
      console.log('An error occurred while adding the deposit.', error);
    }
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Add Feedback</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              name="user_email_address"
              value={userProfile.emailId}
              onChange={handleInputChange}
              disabled
            />
          </Form.Group>

          <Form.Group controlId="formBasicName">
            <Form.Label>UserName</Form.Label>
            <Form.Control
              type="text"
              name="user_name"
              value={userProfile?.userName}
              onChange={handleInputChange}
              disabled
            />
          </Form.Group>
          <Form.Group controlId="querySelect">
              <Form.Label>Is this a query?</Form.Label>
              <Form.Control as="select" name="query"  onChange={handleInputChange}>
                <option value={false}>No</option>
                <option value={true}>Yes</option>
              </Form.Control>
            </Form.Group>
          <Form.Group controlId="formBasicDescription">
            <Form.Label>Description</Form.Label>
            <Form.Control
              as="textarea"
              placeholder="Enter feedback description"
              name="description"
              value={feedback.description}
              onChange={handleInputChange}
            />
          </Form.Group>

          <Button variant="primary" onClick={handleSubmit}>
            Submit
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
}
