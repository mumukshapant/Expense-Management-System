package com.dbms.Expense.Management.Model;

public enum Gender {
    MALE, FEMALE, OTHER;
}
